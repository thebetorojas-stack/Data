# -*- coding: utf-8 -*-
"""
=============================================================================
 FX CROSS-CARRY PAYOFF CHART — long BRL / short CLP via 3m NDFs
=============================================================================
 Draws the 3-month total return of the two-leg NDF position against the
 terminal BRL/CLP cross, with bear / base / bull marked at -1σ / 0 / +1σ of
 the cross (3m implied vols), the carry cushion shaded, and the breakeven.

 The arithmetic is IDENTICAL to the Trade tab of BRLCLP_3m_NDF_Carry.xlsx:
   F        = S + points / scale                           (per leg)
   long-BRL = F_BRL / S_BRL,T - 1
   short-CLP= 1 - F_CLP / S_CLP,T
   σ_X²     = σ_B² + σ_C² - 2 ρ σ_B σ_C      (cross vol from the legs)
   cross move m is split onto the legs by the regression weights
     w_B = (σ_B² - ρ σ_B σ_C) / σ_X²,  w_C = 1 - w_B
     S_BRL,T = S_BRL·exp(-w_B·m),  S_CLP,T = S_CLP·exp(+w_C·m)

 Run:  python fx_cross_carry_chart.py        (needs matplotlib + numpy)
 Out:  OUTDIR/<NAME>.svg  <- insert this into Word (vector)
       OUTDIR/<NAME>.png  <- 600 dpi fallback
       OUTDIR/<NAME>.pdf

 Three ways to feed it
 ---------------------
   python fx_cross_carry_chart.py
       uses the CONFIG block below (manual numbers).
   python fx_cross_carry_chart.py --xlsx BRLCLP_3m_NDF_Carry.xlsx
       reads the Trade tab's "Used" column (the named cells S_BRL, S_CLP,
       P_BRL ... RHO, N, T, BASIS) from the SAVED workbook. BDP values are
       only stored in the file when Excel saves it, so the sequence on the
       terminal is: open -> Bloomberg refresh -> Ctrl+S -> run this.
   python fx_cross_carry_chart.py --live [--paste]
       reads the same named cells from the workbook currently OPEN in Excel
       via xlwings (pip install xlwings), no save needed, and with --paste
       drops the PNG into the Payoff tab next to the Excel chart. This is the
       one-click route: refresh in Bloomberg, run, chart is current.
 Whatever the source, the resolved inputs are printed so you can check them
 against the sheet before the chart goes anywhere.
=============================================================================
"""
import argparse, sys
import math, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

# ------------------------------------------------------------------ CONFIG --
CONFIG = dict(
    NAME        = "BRLCLP_3m_NDF_payoff",
    OUTDIR      = "out",
    # --- market inputs (ILLUSTRATIVE placeholders: replace from Bloomberg) ---
    S_BRL       = 5.40,      # USDBRL spot                      USDBRL BGN Curncy
    S_CLP       = 940.0,     # USDCLP spot                      USDCLP BGN Curncy
    P_BRL       = 1414.0,    # USDBRL 3m NDF points             BCN3M BGN Curncy
    P_CLP       = 232.0,     # USDCLP 3m NDF points             CHN3M BGN Curncy
    SC_BRL      = 10000,     # BRL points scale (FXFA)
    SC_CLP      = 100,       # CLP points scale (FXFA)
    V_BRL       = 14.0,      # USDBRL 3m ATM vol, % p.a.        USDBRLV3M BGN Curncy
    V_CLP       = 12.0,      # USDCLP 3m ATM vol, % p.a.        USDCLPV3M BGN Curncy
    RHO         = 0.55,      # corr of USDBRL vs USDCLP log changes
    T_DAYS      = 91, BASIS = 365,
    NOTIONAL    = 10_000_000,  # USD per leg (only used in the subtitle)
    # --- chart ---
    X_SIGMAS    = 3.0,       # x-axis half-width in cross sigmas
    FIG_W_IN    = 6.3,       # Word text-column width; height follows
    FIG_H_IN    = 4.0,
    FONT        = "Arial",   # falls back to Liberation Sans / DejaVu Sans
    RED         = "#E60000", INK = "#111111", GREY = "#6B6B6B", LIGHT = "#BBBBBB",
    SHADE       = "#E60000", SHADE_ALPHA = 0.08,
    TITLE       = None,      # None -> auto title stating the finding
    SOURCE      = "Source: Bloomberg (NDF points, 3m ATM vols), UBS CIO calculations. Illustrative inputs — refresh from the Trade tab before use.",
)
# -------------------------------------------------------------- END CONFIG --

def model(c):
    T = c["T_DAYS"] / c["BASIS"]
    F_B = c["S_BRL"] + c["P_BRL"] / c["SC_BRL"]
    F_C = c["S_CLP"] + c["P_CLP"] / c["SC_CLP"]
    vB, vC, rho = c["V_BRL"] / 100, c["V_CLP"] / 100, c["RHO"]
    vX = math.sqrt(vB**2 + vC**2 - 2 * rho * vB * vC)
    sig3 = vX * math.sqrt(T)
    wB = (vB**2 - rho * vB * vC) / vX**2; wC = 1 - wB
    X0 = c["S_CLP"] / c["S_BRL"]
    carry3 = (F_B / c["S_BRL"] - 1) + (1 - F_C / c["S_CLP"])
    def legs(m):
        sB = c["S_BRL"] * np.exp(-wB * m); sC = c["S_CLP"] * np.exp(wC * m)
        return sC / sB, F_B / sB - 1, 1 - F_C / sC
    return dict(T=T, F_B=F_B, F_C=F_C, vX=vX, sig3=sig3, wB=wB, wC=wC, X0=X0, carry3=carry3, legs=legs)

def pick_font(name):
    names = {f.name for f in font_manager.fontManager.ttflist}
    for cand in (name, "Liberation Sans", "DejaVu Sans"):
        if cand in names: return cand
    return "sans-serif"

def draw(c):
    m = model(c)
    plt.rcParams["font.family"] = pick_font(c["FONT"])
    ms = np.linspace(-c["X_SIGMAS"] * m["sig3"], c["X_SIGMAS"] * m["sig3"], 601)
    X, lb, sc = m["legs"](ms); tot = lb + sc
    # breakeven by interpolation on the path
    i = np.where(np.diff(np.sign(tot)) != 0)[0]
    be = float(np.interp(0, tot[i[0]:i[0] + 2], X[i[0]:i[0] + 2])) if len(i) else float("nan")
    scen = {}
    for lab, k in (("Bear", -1), ("Base", 0), ("Bull", 1)):
        x, a, b = m["legs"](np.array([k * m["sig3"]])); scen[lab] = (float(x[0]), float(a[0] + b[0]))

    fig, ax = plt.subplots(figsize=(c["FIG_W_IN"], c["FIG_H_IN"]), dpi=100)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    for s in ("left", "bottom"): ax.spines[s].set_color(c["LIGHT"])
    ax.tick_params(colors=c["GREY"], labelsize=8, length=3)
    ax.axhline(0, color=c["INK"], lw=0.8)
    # cushion shade: between breakeven and spot, above zero
    xs = X[(X >= min(be, m["X0"])) & (X <= max(be, m["X0"]))]; ys = np.interp(xs, X, tot)
    ax.fill_between(xs, 0, ys, color=c["SHADE"], alpha=c["SHADE_ALPHA"], lw=0)
    # ±1σ band
    ax.axvspan(scen["Bear"][0], scen["Bull"][0], color="#F2F2F2", zorder=0)
    ax.plot(X, tot, color=c["RED"], lw=2.0, zorder=3)
    ax.plot(X, lb, color=c["GREY"], lw=0.9, ls="--", zorder=2)
    ax.plot(X, sc, color=c["LIGHT"], lw=0.9, ls="--", zorder=2)
    ax.axvline(m["X0"], color=c["GREY"], lw=0.7, ls=":")
    # markers + labels
    cols = {"Bear": c["GREY"], "Base": c["INK"], "Bull": c["RED"]}
    for lab, (x, y) in scen.items():
        ax.plot([x], [y], "o", ms=6.5, color=cols[lab], mec="white", mew=1.0, zorder=5)
        dy = 14 if lab != "Bear" else -18
        ax.annotate(f"{lab}: {y:+.1%}\nBRL/CLP {x:,.1f}", (x, y), textcoords="offset points", xytext=(0, dy),
                    ha="center", va="bottom" if dy > 0 else "top", fontsize=8, color=cols[lab], fontweight="bold")
    ax.annotate(f"Breakeven {be:,.1f}\n({be / m['X0'] - 1:+.1%} vs spot)", (be, 0), textcoords="offset points", xytext=(70, -42),
                ha="center", va="top", fontsize=7.5, color=c["GREY"], arrowprops=dict(arrowstyle="-", color=c["LIGHT"], lw=0.7))
    ax.text(m["X0"], ax.get_ylim()[1], f"spot {m['X0']:,.1f}", fontsize=7, color=c["GREY"], ha="left", va="top")
    ax.set_xlabel("BRL/CLP at the 3-month fixing (CLP per BRL)", fontsize=8.5, color=c["GREY"])
    ax.set_ylabel("Return on USD notional, 3 months", fontsize=8.5, color=c["GREY"])
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=0))
    ax.set_xlim(X.min(), X.max())
    title = c["TITLE"] or (f"Long BRL / short CLP 3m NDF: {m['carry3']:+.1%} carry buys {abs(be / m['X0'] - 1):.1%} of cushion, "
                           f"{abs(math.log(be / m['X0'])) / m['sig3']:.2f}σ of a {m['sig3']:.1%} 3m move")
    fig.text(0.01, 0.985, title, fontsize=10, fontweight="bold", color=c["INK"], ha="left", va="top", wrap=True)
    fig.text(0.01, 0.925, f"Bear / Bull = ±1σ of the cross (σ_X {m['vX']:.1%} p.a. from USDBRL {c['V_BRL']:.0f}%, USDCLP {c['V_CLP']:.0f}%, ρ {c['RHO']:.2f}); "
             f"\n"
             f"cross move split {m['wB']:.0%} onto USDBRL / {m['wC']:.0%} onto USDCLP. Dashed: long-BRL leg (dark) and short-CLP leg (light) alone. Grey band: ±1σ.",
             fontsize=7.2, color=c["GREY"], ha="left", va="top")
    fig.text(0.01, 0.01, c["SOURCE"], fontsize=6.5, color=c["LIGHT"], ha="left", va="bottom")
    fig.subplots_adjust(left=0.11, right=0.98, top=0.80, bottom=0.17)
    os.makedirs(c["OUTDIR"], exist_ok=True)
    for ext, kw in (("svg", {}), ("png", {"dpi": 600}), ("pdf", {})):
        fig.savefig(os.path.join(c["OUTDIR"], f"{c['NAME']}.{ext}"), **kw)
    print(f"carry 3m {m['carry3']:+.3%} | σ_X {m['vX']:.2%} | 1σ/3m {m['sig3']:.2%} | wB {m['wB']:.3f} | X0 {m['X0']:.2f} | BE {be:.2f}")
    for k, v in scen.items(): print(f"  {k:4s} cross {v[0]:7.2f}  return {v[1]:+.2%}")

NAMED = {"S_BRL": "S_BRL", "S_CLP": "S_CLP", "P_BRL": "P_BRL", "P_CLP": "P_CLP", "SC_BRL": "SC_BRL", "SC_CLP": "SC_CLP",
         "V_BRL": "V_BRL", "V_CLP": "V_CLP", "RHO": "RHO", "N": "NOTIONAL", "T": "T_DAYS", "BASIS": "BASIS"}

def from_xlsx(path, cfg):
    """Read the Trade tab's Used column from a SAVED workbook (cached values)."""
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True)
    out = dict(cfg)
    for nm, key in NAMED.items():
        dn = wb.defined_names[nm]
        sheet, ref = next(dn.destinations)
        v = wb[sheet][ref.replace("$", "")].value
        if v is None or isinstance(v, str):
            sys.exit(f"{nm} has no numeric value in {path} (got {v!r}). Refresh Bloomberg and SAVE the file first, or fill the blue override.")
        out[key] = float(v)
    out["SOURCE"] = f"Source: Bloomberg via {os.path.basename(path)} (Trade tab, Used column), UBS CIO calculations."
    return out

def from_live(cfg, paste=False, book="BRLCLP_3m_NDF_Carry.xlsx"):
    """Read the named cells from the workbook open in Excel (xlwings); optionally paste the PNG back."""
    import xlwings as xw
    wb = None
    for b in xw.books:
        if b.name.lower() == book.lower(): wb = b
    if wb is None: wb = xw.books.active
    out = dict(cfg)
    for nm, key in NAMED.items():
        v = wb.names[nm].refers_to_range.value
        if v is None or isinstance(v, str):
            sys.exit(f"{nm} is not numeric in the open workbook (got {v!r}). Refresh Bloomberg first.")
        out[key] = float(v)
    out["SOURCE"] = f"Source: Bloomberg via {wb.name} (live), UBS CIO calculations."
    if paste:
        out["_paste_to"] = wb
    return out

def paste_png(cfg, wb):
    sht = wb.sheets["Payoff"]
    png = os.path.join(cfg["OUTDIR"], f"{cfg['NAME']}.png")
    for pic in list(sht.pictures):
        if pic.name == "payoff_py": pic.delete()
    sht.pictures.add(png, name="payoff_py", left=sht.range("M17").left, top=sht.range("M17").top, width=520)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx", help="read inputs from a saved copy of the workbook")
    ap.add_argument("--live", action="store_true", help="read inputs from the workbook open in Excel (xlwings)")
    ap.add_argument("--paste", action="store_true", help="with --live: paste the PNG into the Payoff tab")
    a = ap.parse_args()
    cfg = CONFIG
    if a.xlsx: cfg = from_xlsx(a.xlsx, CONFIG)
    elif a.live: cfg = from_live(CONFIG, paste=a.paste)
    print("inputs:", {k: cfg[k] for k in ("S_BRL", "S_CLP", "P_BRL", "P_CLP", "SC_BRL", "SC_CLP", "V_BRL", "V_CLP", "RHO", "T_DAYS", "BASIS", "NOTIONAL")})
    draw(cfg)
    if cfg.get("_paste_to") is not None: paste_png(cfg, cfg["_paste_to"]); print("PNG pasted into Payoff!M17")
