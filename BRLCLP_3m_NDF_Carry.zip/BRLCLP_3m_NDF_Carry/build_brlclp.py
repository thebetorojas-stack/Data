# -*- coding: utf-8 -*-
"""
Long BRL / short CLP via 3-month rolling NDFs — Bloomberg-linked workbook.
python3 build_brlclp.py  ->  BRLCLP_3m_NDF_Carry.xlsx

Every market input lives in TWO cells: a live BDP() pull and a blue override.
The model uses the override if it is filled, else the live value. So the file
works on the Bloomberg terminal (leave overrides blank) and offline (fill them).
"""
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import ScatterChart, Reference, Series
from openpyxl.chart.marker import Marker
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.drawing.line import LineProperties
from openpyxl.utils import get_column_letter
from openpyxl.workbook.defined_name import DefinedName

OUT = "/home/claude/brlclp/BRLCLP_3m_NDF_Carry.xlsx"
F = "Arial"; RED = "E60000"; INK = "000000"; GREY = "6B6B6B"; BLUE = "0000FF"; WHITE = "FFFFFF"
INFILL = PatternFill("solid", fgColor="FFF8E1"); HDR = PatternFill("solid", fgColor=RED); OUTFILL = PatternFill("solid", fgColor="F2F2F2")
THIN = Side(style="thin", color="D9D9D9"); BOT = Border(bottom=THIN)

def font(sz=9, b=False, color=INK, i=False): return Font(name=F, size=sz, bold=b, color=color, italic=i)
def base(ws, widths):
    ws.sheet_view.showGridLines = False; ws.sheet_properties.tabColor = RED
    ws.column_dimensions["A"].width = 2
    for i, w in enumerate(widths): ws.column_dimensions[get_column_letter(i + 2)].width = w
def title(ws, t, sub=None):
    c = ws.cell(1, 2, t); c.font = font(14, True, WHITE); c.fill = PatternFill("solid", fgColor=INK); c.alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 26
    if sub: ws.cell(2, 2, sub).font = font(9, False, GREY, True)
def section(ws, r, t): ws.cell(r, 2, t).font = font(11, True, RED)
def hdr(ws, r, names, col=2):
    for j, n in enumerate(names):
        c = ws.cell(r, col + j, n); c.font = font(9, True, WHITE); c.fill = HDR; c.alignment = Alignment(wrap_text=True, vertical="center")
    ws.row_dimensions[r].height = 28
def put(ws, r, c, v, fmt=None, kind="calc", bold=False, wrap=False):
    cell = ws.cell(r, c, v)
    if kind == "in": cell.font = font(9, bold, BLUE); cell.fill = INFILL
    elif kind == "live": cell.font = font(9, bold, "7F7F7F")
    elif kind == "out": cell.font = font(9, True, INK); cell.fill = OUTFILL
    elif kind == "label": cell.font = font(9, bold, INK)
    elif kind == "note": cell.font = font(8, False, GREY, True)
    else: cell.font = font(9, bold, INK)
    if fmt: cell.number_format = fmt
    cell.border = BOT
    cell.alignment = Alignment(wrap_text=wrap, vertical="top" if wrap else "center")
    return cell

wb = Workbook(); wb.remove(wb.active)

# ============================================================== README =====
ws = wb.create_sheet("README"); base(ws, [30, 120]); title(ws, "Long BRL / short CLP via 3-month rolling NDFs", "TAA trade proposal — Bloomberg-linked. Built 2026-10-22. INTERNAL.")
rows = [
 ("s", "What this file does"),
 ("t", "Prices a long BRL / short CLP position built from two equal-USD-notional 3-month non-deliverable forwards, shows where the carry comes from, and lays out bear / base / bull outcomes defined as a one-standard-deviation move of the BRL/CLP cross over three months using 3-month implied vols. Then shows how the position is rolled every quarter."),
 ("s", "How it is linked to Bloomberg"),
 ("t", "Open on the terminal PC with the Bloomberg Excel add-in loaded. Every market input on the Trade tab has a LIVE cell (grey, a BDP formula) and an OVERRIDE cell (blue). The model uses the override when it is filled and the live value otherwise. Leave overrides blank on the terminal; fill them when working offline. Press the Bloomberg 'Refresh Workbook' button if the live cells show #NAME? or #N/A on first open."),
 ("t", "Tickers used (all BGN Curncy): USDBRL / USDCLP spot; BCN3M / CHN3M (NDF forward points); BCNI3M / CHNI3M (NDF-implied yields); USDBRLV3M / USDCLPV3M (3m ATM implied vol); USOSFRC (3m SOFR OIS); BRLCLP (cross spot). Check the forward-point scale factors on FXFA <GO> — BRL points are quoted in 1/10,000 and CLP points in 1/100 by default; both are blue inputs."),
 ("s", "The trade, in one line"),
 ("t", "Sell USD / buy BRL 3m NDF at outright F_BRL, and buy USD / sell CLP 3m NDF at outright F_CLP, same USD notional on each leg. You earn the BRL NDF-implied yield and pay the CLP NDF-implied yield; the USD legs net out. Net carry = i_BRL − i_CLP, accrued for 3 months, and it is paid to you only if the cross finishes where it started. The carry is the spot risk: there is no way to keep one and shed the other without changing the instrument."),
 ("s", "Payoff arithmetic (USD notional N per leg, pairs quoted as local per USD)"),
 ("t", "Long-BRL leg at maturity:  P&L_USD = N × (F_BRL / S_BRL,T − 1).   Short-CLP leg:  P&L_USD = N × (1 − F_CLP / S_CLP,T).   Total = sum of the two. Each leg is exact, not an approximation; the familiar 'carry + spot return' form is only an approximation and does not return zero at breakeven."),
 ("t", "Forward from points:  F = S + points / scale.   Implied yield check:  i_local = [(F/S) × (1 + i_USD × T) − 1] / T, which should reconcile to the BCNI3M / CHNI3M tickers to within the cross-currency basis."),
 ("s", "Scenarios"),
 ("t", "Cross vol is built from the two legs: sigma_X² = sigma_BRL² + sigma_CLP² − 2 × rho × sigma_BRL × sigma_CLP, where rho is the correlation of USDBRL and USDCLP log changes (blue input; default is the 3-month realised figure, or pull BRLCLPV3M if your desk has it and back out rho). The 3-month 1-sigma move is sigma_X × sqrt(T)."),
 ("t", "Bull = BRL strengthens 1 sigma against CLP; Bear = BRL weakens 1 sigma against CLP; Base = both spots unchanged (full carry earned). A cross move m is split onto the legs by their vol contribution: USDBRL moves by −w_BRL × m and USDCLP by +w_CLP × m, with w_BRL = (sigma_BRL² − rho sigma_BRL sigma_CLP)/sigma_X² and w_CLP = 1 − w_BRL. That is the regression split, so the scenarios are internally consistent with the correlation you typed in."),
 ("t", "Breakeven cross is where total P&L is zero; cushion = distance from spot to breakeven in % of the cross. Carry-to-vol = annualised net carry / cross vol, the usual one-number quality check."),
 ("s", "Rolling"),
 ("t", "The Roll tab lays out four consecutive 3-month contracts from the trade date. Each roll restrikes both legs at the then-prevailing 3m forwards; realised P&L of the maturing contract is booked in USD and the new contract starts at the new spot. Transaction cost per roll is an input in forward pips on each leg."),
 ("s", "Colour code"),
 ("t", "Blue on cream = input you can change. Grey = live Bloomberg pull. Bold on grey = model output. Black = formula."),
 ("s", "Not in this file"),
 ("t", "No probabilities on the scenarios: 1 sigma is a market-implied distance, not a view. No cross-currency basis isolation. No option overlays. No tax or settlement mechanics (BRL NDFs fix on PTAX, CLP NDFs on the Dólar Observado — both T-2 fixing conventions matter for the roll dates and are noted on the Roll tab)."),
]
r = 4
for k, t in rows:
    if k == "s": section(ws, r, t)
    else:
        c = ws.cell(r, 2, t); c.font = font(9); c.alignment = Alignment(wrap_text=True, vertical="top"); ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=3)
        ws.row_dimensions[r].height = 14 * max(1, -(-len(t) // 150))
    r += 1

# ============================================================== TRADE ======
t = wb.create_sheet("Trade"); base(t, [34, 20, 20, 20, 18, 62]); title(t, "Trade inputs and calculation", "Live Bloomberg pulls in grey; blue overrides win when filled. All other cells are formulas.")
section(t, 4, "1. Market inputs")
hdr(t, 5, ["Input", "Live (BDP)", "Override", "Used", "Units", "Ticker / note"])
inputs = [
 # key, label, bdp, override_default, fmt, units, note
 ("S_BRL", "USDBRL spot", '=BDP("USDBRL BGN Curncy","PX_LAST")', 5.40, "0.0000", "BRL per USD", "USDBRL BGN Curncy"),
 ("S_CLP", "USDCLP spot", '=BDP("USDCLP BGN Curncy","PX_LAST")', 940.0, "0.00", "CLP per USD", "USDCLP BGN Curncy"),
 ("P_BRL", "USDBRL 3m NDF points", '=BDP("BCN3M BGN Curncy","PX_LAST")', 1414.0, "0.0", "points", "BCN3M BGN Curncy — NDF (offshore) points. Scale below."),
 ("P_CLP", "USDCLP 3m NDF points", '=BDP("CHN3M BGN Curncy","PX_LAST")', 232.0, "0.0", "points", "CHN3M BGN Curncy — NDF points. Scale below."),
 ("SC_BRL", "BRL points scale", None, 10000, "0", "divisor", "Check FXFA <GO>. Default 10,000 (pips)."),
 ("SC_CLP", "CLP points scale", None, 100, "0", "divisor", "Check FXFA <GO>. Default 100."),
 ("I_BRL", "BRL 3m NDF-implied yield", '=BDP("BCNI3M BGN Curncy","PX_LAST")', 14.20, "0.00", "% p.a.", "BCNI3M BGN Curncy — reconciliation only; model uses the points."),
 ("I_CLP", "CLP 3m NDF-implied yield", '=BDP("CHNI3M BGN Curncy","PX_LAST")', 4.60, "0.00", "% p.a.", "CHNI3M BGN Curncy — reconciliation only."),
 ("I_USD", "USD 3m SOFR OIS", '=BDP("USOSFRC BGN Curncy","PX_LAST")', 3.60, "0.00", "% p.a.", "USOSFRC BGN Curncy. Used to back out implied yields from the points."),
 ("V_BRL", "USDBRL 3m ATM implied vol", '=BDP("USDBRLV3M BGN Curncy","PX_LAST")', 14.0, "0.00", "% p.a.", "USDBRLV3M BGN Curncy"),
 ("V_CLP", "USDCLP 3m ATM implied vol", '=BDP("USDCLPV3M BGN Curncy","PX_LAST")', 12.0, "0.00", "% p.a.", "USDCLPV3M BGN Curncy"),
 ("RHO", "Correlation USDBRL vs USDCLP (3m)", '=BDP("USDBRL BGN Curncy","CORRELATION_90D_VS_INDEX","CORRELATION_INDEX_TICKER=USDCLP BGN Curncy")', 0.55, "0.00", "rho", "Realised 90d proxy. Overwrite with implied if your desk quotes BRLCLPV3M: rho = (vB²+vC²−vX²)/(2 vB vC)."),
 ("N", "USD notional per leg", None, 10000000, "#,##0", "USD", "Same notional on both legs."),
 ("T", "Tenor", None, 91, "0", "days", "3m NDF; year basis 365 below."),
 ("BASIS", "Day-count basis", None, 365, "0", "days/yr", "Actual/365 for the carry accrual. Use 360 if you prefer the money-market convention; it changes the 4th decimal."),
 ("TD", "Trade date", None, "=TODAY()", "dd-mmm-yyyy", "date", "Overwrite with the actual trade date."),
]
names = {}
r = 6
for key, label, bdp, ov, fmt, units, note in inputs:
    put(t, r, 2, label, kind="label")
    if bdp: put(t, r, 3, bdp, fmt, kind="live")
    else: put(t, r, 3, "—", kind="live")
    put(t, r, 4, ov, fmt, kind="in")
    if bdp: put(t, r, 5, f'=IF(ISNUMBER(D{r}),D{r},IF(ISNUMBER(C{r}),C{r},NA()))', fmt, kind="out")
    else: put(t, r, 5, f"=D{r}", fmt, kind="out")
    put(t, r, 6, units); put(t, r, 7, note, kind="note", wrap=True)
    names[key] = f"Trade!$E${r}"
    wb.defined_names[key] = DefinedName(key, attr_text=names[key])
    r += 1
t.column_dimensions["G"].width = 70
put(t, r, 2, "Override defaults are ILLUSTRATIVE placeholders so the file computes offline. On the terminal, clear column D (rows 6-17 where a live ticker exists) so the live values flow through.", kind="note", wrap=True); t.merge_cells(start_row=r, start_column=2, end_row=r, end_column=7); t.row_dimensions[r].height = 26
r += 2

section(t, r, "2. Forwards, implied yields and carry"); r += 1
hdr(t, r, ["Item", "BRL leg", "CLP leg", "Net / cross", "Units", "Formula"]); r += 1
calc = [
 ("yf", "Year fraction T", "=T/BASIS", "=T/BASIS", None, "years", "T / basis"),
 ("F", "3m NDF outright", "=S_BRL+P_BRL/SC_BRL", "=S_CLP+P_CLP/SC_CLP", None, "local per USD", "F = S + points / scale"),
 ("fp", "Forward premium of USD", "=F_BRL/S_BRL-1", "=F_CLP/S_CLP-1", "=D{fp}-C{fp}", "% over 3m", "F/S − 1. Positive = local currency at a forward discount = you are paid to be long it."),
 ("iy", "Implied local yield from points", "=((F_BRL/S_BRL)*(1+I_USD/100*yf_BRL)-1)/yf_BRL", "=((F_CLP/S_CLP)*(1+I_USD/100*yf_CLP)-1)/yf_CLP", "=C{iy}-D{iy}", "% p.a. (decimal)", "Covered parity: i_local = [(F/S)(1 + i_USD T) − 1]/T"),
 ("chk", "Bloomberg implied yield (check)", "=I_BRL/100", "=I_CLP/100", "=C{chk}-D{chk}", "% p.a. (decimal)", "BCNI3M / CHNI3M. Gap to the row above = basis + bid/offer."),
 ("c3", "Carry earned over 3m, per leg", "=F_BRL/S_BRL-1", "=1-F_CLP/S_CLP", "=C{c3}+D{c3}", "% of notional", "Long-BRL leg: F/S − 1 at unchanged spot. Short-CLP leg: 1 − F/S at unchanged spot."),
 ("c3u", "Carry over 3m in USD", "=C{c3}*N", "=D{c3}*N", "=E{c3}*N", "USD", "× notional"),
 ("cann", "Net carry annualised", None, None, "=E{c3}/yf_BRL", "% p.a.", "Net 3m carry / T. This is the number the trade is 'paid'."),
]
rowmap = {}
start = r
for key, label, b, c, d, units, formula in calc:
    rowmap[key] = r; r += 1
def fx(s):
    if s is None: return None
    for k, v in rowmap.items(): s = s.replace("{" + k + "}", str(v))
    return s
r = start
for key, label, b, c, d, units, formula in calc:
    put(t, r, 2, label, kind="label")
    fmt = "0.0000" if key in ("F",) else ("0.000%" if key in ("fp", "iy", "chk", "c3", "cann") else ("#,##0" if key == "c3u" else "0.0000"))
    if b: put(t, r, 3, fx(b), fmt, kind="out" if key in ("F", "c3") else "calc")
    if c: put(t, r, 4, fx(c), fmt, kind="out" if key in ("F", "c3") else "calc")
    if d: put(t, r, 5, fx(d), fmt, kind="out" if key in ("c3", "cann", "c3u") else "calc")
    put(t, r, 6, units); put(t, r, 7, formula, kind="note", wrap=True)
    r += 1
# named cells
for key, col in [("F_BRL", "C"), ("F_CLP", "D")]:
    wb.defined_names[key] = DefinedName(key, attr_text=f"Trade!${col}${rowmap['F']}")
wb.defined_names["yf_BRL"] = DefinedName("yf_BRL", attr_text=f"Trade!$C${rowmap['yf']}")
wb.defined_names["yf_CLP"] = DefinedName("yf_CLP", attr_text=f"Trade!$D${rowmap['yf']}")
wb.defined_names["CARRY3M"] = DefinedName("CARRY3M", attr_text=f"Trade!$E${rowmap['c3']}")
wb.defined_names["CARRYANN"] = DefinedName("CARRYANN", attr_text=f"Trade!$E${rowmap['cann']}")
r += 1

section(t, r, "3. Volatility and the 1-sigma scenario distance"); r += 1
hdr(t, r, ["Item", "BRL leg", "CLP leg", "Cross BRL/CLP", "Units", "Formula"]); r += 1
v0 = r
put(t, r, 2, "3m ATM implied vol (annualised)", kind="label"); put(t, r, 3, "=V_BRL/100", "0.00%"); put(t, r, 4, "=V_CLP/100", "0.00%")
put(t, r, 5, f"=SQRT(C{r}^2+D{r}^2-2*RHO*C{r}*D{r})", "0.00%", kind="out"); put(t, r, 6, "% p.a."); put(t, r, 7, "sigma_X = sqrt(vB² + vC² − 2 rho vB vC)", kind="note"); r += 1
put(t, r, 2, "1-sigma move over the tenor", kind="label"); put(t, r, 3, f"=C{v0}*SQRT(yf_BRL)", "0.00%"); put(t, r, 4, f"=D{v0}*SQRT(yf_CLP)", "0.00%")
put(t, r, 5, f"=E{v0}*SQRT(yf_BRL)", "0.00%", kind="out"); put(t, r, 6, "% (log)"); put(t, r, 7, "sigma × sqrt(T)", kind="note"); r += 1
put(t, r, 2, "Weight of each leg in a cross move", kind="label"); put(t, r, 3, f"=(C{v0}^2-RHO*C{v0}*D{v0})/E{v0}^2", "0.000"); put(t, r, 4, f"=1-C{r}", "0.000")
put(t, r, 5, "=1", "0.000"); put(t, r, 6, "share"); put(t, r, 7, "w_BRL = (vB² − rho vB vC)/vX²; w_CLP = 1 − w_BRL. Regression split of a cross move onto the legs.", kind="note", wrap=True); r += 1
put(t, r, 2, "Carry-to-vol (annualised)", kind="label"); put(t, r, 5, f"=CARRYANN/E{v0}", "0.00", kind="out"); put(t, r, 6, "ratio"); put(t, r, 7, "Net carry p.a. / cross vol. Above ~0.5 is the usual bar for an outright carry trade.", kind="note"); r += 1
wb.defined_names["SIG_X"] = DefinedName("SIG_X", attr_text=f"Trade!$E${v0}")
wb.defined_names["SIG_X3M"] = DefinedName("SIG_X3M", attr_text=f"Trade!$E${v0+1}")
wb.defined_names["W_BRL"] = DefinedName("W_BRL", attr_text=f"Trade!$C${v0+2}")
wb.defined_names["W_CLP"] = DefinedName("W_CLP", attr_text=f"Trade!$D${v0+2}")
r += 1

section(t, r, "4. Bear / base / bull at the 3-month maturity"); r += 1
hdr(t, r, ["Scenario", "Bear (BRL −1σ vs CLP)", "Base (spots unchanged)", "Bull (BRL +1σ vs CLP)", "Units", "Formula"]); r += 1
s0 = r
# cross move m
put(t, r, 2, "Cross log move m", kind="label"); put(t, r, 3, "=-SIG_X3M", "0.00%"); put(t, r, 4, "=0", "0.00%"); put(t, r, 5, "=SIG_X3M", "0.00%"); put(t, r, 6, "log"); put(t, r, 7, "±1 sigma of the cross over 3 months. Positive = BRL stronger vs CLP.", kind="note"); r += 1
put(t, r, 2, "Terminal USDBRL", kind="label")
for j, col in enumerate("CDE"): put(t, r, 3 + j, f"=S_BRL*EXP(-W_BRL*{col}{s0})", "0.0000")
put(t, r, 6, "BRL per USD"); put(t, r, 7, "S_BRL × exp(−w_BRL × m)", kind="note"); r += 1
put(t, r, 2, "Terminal USDCLP", kind="label")
for j, col in enumerate("CDE"): put(t, r, 3 + j, f"=S_CLP*EXP(W_CLP*{col}{s0})", "0.00")
put(t, r, 6, "CLP per USD"); put(t, r, 7, "S_CLP × exp(+w_CLP × m)", kind="note"); r += 1
put(t, r, 2, "Terminal BRL/CLP cross", kind="label")
for j, col in enumerate("CDE"): put(t, r, 3 + j, f"={col}{s0+2}/{col}{s0+1}", "0.00")
put(t, r, 6, "CLP per BRL"); put(t, r, 7, "USDCLP / USDBRL", kind="note"); r += 1
put(t, r, 2, "Cross move vs spot", kind="label")
for j, col in enumerate("CDE"): put(t, r, 3 + j, f"={col}{s0+3}/(S_CLP/S_BRL)-1", "0.00%")
put(t, r, 6, "%"); put(t, r, 7, "Simple % change of the cross", kind="note"); r += 1
put(t, r, 2, "P&L long-BRL leg", kind="label")
for j, col in enumerate("CDE"): put(t, r, 3 + j, f"=(F_BRL/{col}{s0+1}-1)", "0.00%")
put(t, r, 6, "% of N"); put(t, r, 7, "F_BRL / S_T − 1", kind="note"); r += 1
put(t, r, 2, "P&L short-CLP leg", kind="label")
for j, col in enumerate("CDE"): put(t, r, 3 + j, f"=(1-F_CLP/{col}{s0+2})", "0.00%")
put(t, r, 6, "% of N"); put(t, r, 7, "1 − F_CLP / S_T", kind="note"); r += 1
put(t, r, 2, "Total return on notional", kind="label")
for j, col in enumerate("CDE"): put(t, r, 3 + j, f"={col}{s0+5}+{col}{s0+6}", "0.00%", kind="out")
put(t, r, 6, "% of N"); put(t, r, 7, "Sum of the legs. Base = net 3m carry exactly.", kind="note"); r += 1
put(t, r, 2, "Total P&L", kind="label")
for j, col in enumerate("CDE"): put(t, r, 3 + j, f"={col}{s0+7}*N", "#,##0;[Red]-#,##0", kind="out")
put(t, r, 6, "USD"); put(t, r, 7, "× notional per leg", kind="note"); r += 1
put(t, r, 2, "Of which carry / of which spot", kind="label")
for j, col in enumerate("CDE"): put(t, r, 3 + j, f'=TEXT(CARRY3M,"0.00%")&" / "&TEXT({col}{s0+7}-CARRY3M,"+0.00%;-0.00%")', None)
put(t, r, 6, "% / %"); put(t, r, 7, "Carry is fixed at inception; the residual is the spot effect (including the convexity term).", kind="note", wrap=True); r += 1
wb.defined_names["SCEN_ROW"] = DefinedName("SCEN_ROW", attr_text=f"Trade!$C${s0+7}:$E${s0+7}")
scen_total_row = s0 + 7; scen_cross_row = s0 + 3
r += 1
section(t, r, "5. Breakeven"); r += 1
put(t, r, 2, "Breakeven cross (P&L = 0), solved on the regression path", kind="label")
be_r = r
# Solve numerically is not possible in-cell; use the approximation m* such that total=0 via first-order then refine? Use a lookup on the Payoff schedule instead.
put(t, r, 5, "=Payoff!$J$5", "0.00", kind="out"); put(t, r, 6, "CLP per BRL"); put(t, r, 7, "Interpolated from the Payoff schedule (sign change of total P&L).", kind="note"); r += 1
put(t, r, 2, "Cushion: cross can fall this much before you lose", kind="label"); put(t, r, 5, f"=E{be_r}/(S_CLP/S_BRL)-1", "0.00%", kind="out"); put(t, r, 6, "%"); put(t, r, 7, "Breakeven / spot cross − 1. Compare with the 1-sigma distance above.", kind="note"); r += 1
put(t, r, 2, "Cushion in sigmas", kind="label"); put(t, r, 5, f"=-LN(E{be_r}/(S_CLP/S_BRL))/SIG_X3M", "0.00", kind="out"); put(t, r, 6, "σ"); put(t, r, 7, "How many 3m standard deviations of adverse cross move the carry absorbs.", kind="note"); r += 1
t.freeze_panes = "B6"

# ============================================================== PAYOFF =====
p = wb.create_sheet("Payoff"); base(p, [14, 14, 14, 14, 14, 14, 14, 16, 8, 18, 18]); title(p, "Payoff at the 3-month maturity across terminal BRL/CLP", "Each row moves the cross by m (log) and splits it onto the legs with the regression weights from the Trade tab.")
hdr(p, 4, ["m (σ units)", "m (log)", "USDBRL_T", "USDCLP_T", "BRL/CLP_T", "Long-BRL leg", "Short-CLP leg", "Total return", "", "Breakeven cross", "Spot cross"])
put(p, 5, 11, "=S_CLP/S_BRL", "0.00", kind="out")
first = 5; n_rows = 41
for i in range(n_rows):
    rr = first + i; k = -3 + i * 0.15
    put(p, rr, 2, round(k, 2), "0.00", kind="in" if i == 0 else "calc")
    put(p, rr, 3, f"=B{rr}*SIG_X3M", "0.00%")
    put(p, rr, 4, f"=S_BRL*EXP(-W_BRL*C{rr})", "0.0000")
    put(p, rr, 5, f"=S_CLP*EXP(W_CLP*C{rr})", "0.00")
    put(p, rr, 6, f"=E{rr}/D{rr}", "0.00")
    put(p, rr, 7, f"=F_BRL/D{rr}-1", "0.00%")
    put(p, rr, 8, f"=1-F_CLP/E{rr}", "0.00%")
    put(p, rr, 9, f"=G{rr}+H{rr}", "0.00%", kind="out")
last = first + n_rows - 1
# breakeven: interpolate where I changes sign (monotonic increasing in m)
put(p, 5, 10, f'=FORECAST(0,OFFSET($F$5,MATCH(0,$I$5:$I${last},1)-1,0,2),OFFSET($I$5,MATCH(0,$I$5:$I${last},1)-1,0,2))', "0.00", kind="out")
put(p, 6, 10, "Linear interpolation between the two schedule rows that bracket zero.", kind="note", wrap=True); p.merge_cells("J6:K8")
# scenario marker table for chart
put(p, 10, 10, "Scenario markers", kind="label"); hdr(p, 11, ["Cross", "Return"], col=10)
for j, (lab, col) in enumerate([("Bear", "C"), ("Base", "D"), ("Bull", "E")]):
    put(p, 12 + j, 9, lab, kind="label"); put(p, 12 + j, 10, f"=Trade!{col}{scen_cross_row}", "0.00"); put(p, 12 + j, 11, f"=Trade!{col}{scen_total_row}", "0.00%")
p.column_dimensions["I"].width = 8
ch = ScatterChart(); ch.title = "Total return at maturity vs terminal BRL/CLP"; ch.style = 2; ch.height = 9.5; ch.width = 18
ch.x_axis.title = "BRL/CLP at maturity (CLP per BRL)"; ch.y_axis.title = "Return on USD notional"; ch.y_axis.number_format = "0%"; ch.legend.position = "b"
xs = Reference(p, min_col=6, min_row=first, max_row=last); ys = Reference(p, min_col=9, min_row=first - 1, max_row=last)
s = Series(ys, xs, title_from_data=True); s.marker = Marker(symbol="none"); s.graphicalProperties.line.solidFill = RED; s.graphicalProperties.line.width = 28000; ch.series.append(s)
for j, (lab, colr) in enumerate([("Bear", "7F7F7F"), ("Base", "000000"), ("Bull", RED)]):
    sx = Reference(p, min_col=10, min_row=12 + j); sy = Reference(p, min_col=11, min_row=12 + j)
    ss = Series(sy, sx, title=lab); ss.marker = Marker(symbol="circle", size=9); ss.marker.graphicalProperties = GraphicalProperties(solidFill=colr); ss.marker.graphicalProperties.line.solidFill = colr
    ss.graphicalProperties.line.noFill = True; ch.series.append(ss)
ch.x_axis.majorGridlines = None
p.add_chart(ch, "J17")
p.freeze_panes = "B5"

# ============================================================== ROLL =======
q = wb.create_sheet("Roll"); base(q, [12, 14, 14, 16, 16, 16, 16, 16, 16, 60]); title(q, "Rolling the position: four consecutive 3-month NDFs", "Each roll restrikes both legs at the prevailing 3m forwards. Inputs in blue. Future carry defaults to today's; overwrite as the curve moves.")
section(q, 4, "Inputs")
put(q, 5, 2, "Transaction cost per roll, per leg", kind="label"); put(q, 5, 5, 0.0005, "0.000%", kind="in"); put(q, 5, 6, "% of notional (both legs, round trip). ~5bp is a reasonable all-in for BRL+CLP NDF bid/offer; check with the desk.", kind="note")
put(q, 6, 2, "Assumed net 3m carry on future rolls", kind="label"); put(q, 6, 5, "=CARRY3M", "0.000%", kind="in"); put(q, 6, 6, "Defaults to today's net carry. The forward curve, not today's spot, decides what you actually lock in each quarter.", kind="note")
put(q, 7, 2, "Assumed cross path", kind="label"); put(q, 7, 5, "Flat", kind="in"); put(q, 7, 6, "Informational. The P&L column below shows carry only; the spot effect per quarter is the Payoff tab applied to each contract.", kind="note")
hdr(q, 9, ["Roll #", "Trade date", "Fixing date", "Settlement", "Long-BRL carry", "Short-CLP carry", "Net carry", "Cost", "Cumulative net", "Mechanics"])
mech = [
 "Contract 1: sell USD/buy BRL at F_BRL, buy USD/sell CLP at F_CLP, same USD notional. Both cash-settle in USD.",
 "Contract 2: on the fixing date of contract 1, book its P&L (Payoff tab) and deal two new 3m NDFs at the new spots and forwards. The carry you lock in is whatever the curve offers that day.",
 "Contract 3: same. Watch BCB and BCCh meeting dates relative to roll dates — the forward curve reprices the carry before the spot moves.",
 "Contract 4: same. After four rolls the position has earned roughly 4 × quarterly net carry less 4 × costs, plus or minus the cumulative spot effect.",
]
for i in range(4):
    rr = 10 + i
    put(q, rr, 2, i + 1, "0")
    put(q, rr, 3, "=TD" if i == 0 else f"=D{rr-1}", "dd-mmm-yy")
    put(q, rr, 4, f"=EDATE(C{rr},3)-2", "dd-mmm-yy")
    put(q, rr, 5, f"=EDATE(C{rr},3)", "dd-mmm-yy")
    put(q, rr, 6, "=Trade!C" + str(rowmap["c3"]) if i == 0 else f"=$E$6*Trade!C{rowmap['c3']}/CARRY3M", "0.000%")
    put(q, rr, 7, "=Trade!D" + str(rowmap["c3"]) if i == 0 else f"=$E$6*Trade!D{rowmap['c3']}/CARRY3M", "0.000%")
    put(q, rr, 8, f"=F{rr}+G{rr}", "0.000%", kind="out")
    put(q, rr, 9, "=-$E$5", "0.000%")
    put(q, rr, 10, f"=H{rr}+I{rr}" if i == 0 else f"=J{rr-1}+H{rr}+I{rr}", "0.000%", kind="out")
    put(q, rr, 11, mech[i], kind="note", wrap=True); q.row_dimensions[rr].height = 40
put(q, 15, 2, "12-month carry, net of costs", kind="label"); put(q, 15, 10, "=J13", "0.000%", kind="out"); put(q, 15, 11, "Compare with the annualised net carry on the Trade tab; the difference is the roll cost and the absence of compounding.", kind="note")
put(q, 16, 2, "In USD", kind="label"); put(q, 16, 10, "=J15*N", "#,##0", kind="out")
section(q, 18, "Fixing conventions")
for i, tx in enumerate([
 "BRL NDFs fix on PTAX (BCB, published ~13:15 Sao Paulo) two business days before settlement; CLP NDFs fix on the Dolar Observado (BCCh) two business days before settlement. Brazilian and Chilean holidays differ — confirm the fixing calendar for each roll with the desk so both legs fix on the same day.",
 "Rolling two days before settlement avoids an unhedged gap between the maturing and the new contract. The EDATE(...)-2 in the fixing column is a placeholder for the business-day-adjusted date.",
 "Each roll crystallises P&L in USD. A losing quarter is realised, not deferred — size the position so that a 1-sigma quarter (Trade tab, Bear column) is tolerable.",
]):
    c = q.cell(19 + i, 2, tx); c.font = font(9); c.alignment = Alignment(wrap_text=True, vertical="top"); q.merge_cells(start_row=19 + i, start_column=2, end_row=19 + i, end_column=11); q.row_dimensions[19 + i].height = 28

wb.calculation.fullCalcOnLoad = True
wb.save(OUT); print("wrote", OUT)
