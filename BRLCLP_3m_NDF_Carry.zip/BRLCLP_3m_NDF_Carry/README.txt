Long BRL / short CLP via 3m rolling NDFs — TAA trade pack (built 2026-10-22)

FILES
  BRLCLP_3m_NDF_Carry.xlsx      Bloomberg-linked workbook: README, Trade, Payoff (Excel chart), Roll.
                                 Grey = BDP live pull, blue = override (wins when filled). Override cells
                                 hold ILLUSTRATIVE placeholders so the file computes offline — on the
                                 terminal clear Trade!D6:D17 and refresh.
  fx_cross_carry_chart.py        Payoff chart. Same arithmetic as the Trade tab.
  BRLCLP_3m_NDF_payoff.svg/.png/.pdf   Chart on the placeholder inputs. Regenerate before use.
  build_brlclp.py                Rebuilds the workbook from scratch (openpyxl). Only needed if you change the model.

REGENERATE THE CHART FROM LIVE BLOOMBERG DATA
  pip install matplotlib openpyxl xlwings
  Option A (one click, workbook open in Excel, Bloomberg refreshed):
      python fx_cross_carry_chart.py --live --paste
      -> reads the named input cells from the open workbook, writes svg/png/pdf to ./out,
         pastes the PNG into Payoff!M17.
  Option B (no xlwings): refresh -> Ctrl+S -> python fx_cross_carry_chart.py --xlsx BRLCLP_3m_NDF_Carry.xlsx
  Option C: edit the CONFIG block at the top of the script and run it with no arguments.
  Set OUTDIR in CONFIG to wherever you want the files (default is a Linux path from the build machine).

CHECK BEFORE USE
  - Forward-point scale factors (Trade!D10:D11) against FXFA <GO>.
  - Correlation: default is 90-day realised; back out implied from BRLCLPV3M if the desk quotes it.
  - Fixing calendars (PTAX / Dolar Observado) for each roll date.
