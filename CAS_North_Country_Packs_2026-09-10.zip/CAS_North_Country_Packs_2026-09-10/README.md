# CAS North — Country Packs

**Built 10 September 2026.** Market awareness briefs for advisor planning.

INTERNAL — pending supervisory review. Factual reference only. Contains no recommendations, no suitability views and no positioning claims.

---

## Folder structure

```
CAS_North_Country_Packs_2026-09-10/
├── README.md
├── CAS_North_Regional_Overview_2026-09-10.pptx     ← start here
├── CAS_North_Regional_Overview_2026-09-10.xlsx     ← the working directory
├── Panama/
├── Costa_Rica/
├── Guatemala/
├── El_Salvador/
├── Dominican_Republic/
├── Colombia/
└── Guyana/
```

Each country folder holds two files:

| File | What it is |
|---|---|
| `<Country>_Brief_2026-09-10.pptx` | ~20 slides. The orientation layer — read before a client conversation. |
| `<Country>_Workbook_2026-09-10.xlsx` | 9 tabs, filterable. Carries the full text and is the working document. |

The country decks truncate long entries; the workbooks never do. When a slide says *"full text in the workbook,"* that is literal.

---

## What each deliverable answers

**Regional overview** — the seven markets side by side on size, growth, inflation, currency regime and who governs them; the six framing points that apply across all of them, how regional wealth is actually organised, and the shared reference tables (ratings, calendar, traps, gaps, sources). The workbook adds a consolidated **Group Directory** of all 71 family groups across the seven markets, and a consolidated **Access Map** — both filterable by market and by confidence grade.

**Country packs** — the same questions in the same order for every market:

1. What an advisor needs to know
2. **Size, growth and inflation** — measured against the ECLAC regional benchmark
3. **What the economy is made of** — sector composition
4. **Who is in charge** — president, party, term, policy orientation, and governability
5. **Policy and macro framework** — currency regime, monetary policy, capital account, fiscal rules
6. What drives the economy — and separately, where the private wealth came from
7. Sectors and the principal names in each
8. The family groups, what they own, and what is live
9. Banking and wealth landscape, including who actually owns the local banks
10. Published institutional access map
11. Listed exposure, including the names that are traps
12. Dated events on the public record, plus practical notes
13. What we do not have

### The benchmark
Everything macro is stated against **ECLAC's August 2026 update**: Latin America and the Caribbean at **2.2%** real GDP growth for 2026 (2.4% in 2025), Central America at **3.0%**, median regional inflation near **3.0%**. Growth decelerates in 24 of the region's 33 economies in 2026.

Six of these seven markets sit above the regional figure. This is the fast half of Latin America, not the average of it.

---

## Method

### Confidence grading
Every substantive row carries a grade.

| Grade | Meaning |
|---|---|
| **A** | Primary document or named agency action |
| **B** | Well-established public record, multiple independent sources |
| **C** | Widely reported, not independently verified — **check before client use** |
| **X** | Contradicted, stale or disputed — **do not use without checking** |

Rows graded X are shaded red in both the decks and the workbooks.

Current distribution across the 71 groups: **14 A, 41 B, 14 C, 2 X.**

### What we deliberately do not assert
No personal banking relationships. No personal contact details. Nothing sourced from LinkedIn. None of it is public, and inferring it in a supervised document is a liability.

In its place: **the published institutional map** — board seats, apex business association roles, foundation leadership, endowed university positions and scholarships, exchange and issuer relationships, and named adviser, bookrunner, arranger and lender roles on disclosed transactions. All of it verifiable, citable, and durable through a compliance review.

### A note on GDP levels
Nominal GDP and GDP per capita in this pack are **indicative orders of magnitude, graded C**. They are correct for sizing a market against its neighbours and are **not** correct to quote to a decimal. Pull exact figures from the IMF WEO or the national statistics office before client use.

Panama is a special case: it is genuinely absent from the IMF WEO DataMapper. Its growth cells are deliberately left unfilled rather than borrowing a number of unknown provenance. Use MEF and INEC Panama.

### Honest flagging over filled-in estimates
Where primary data was unavailable, the gap is documented with the exact source identifier needed to close it. Nothing has been filled with a modelled proxy. See the **Gaps** tab in every workbook.

Two sovereign rating rows — Dominican Republic and Colombia — are stale and are marked X. They must be refreshed from the agencies before any client-facing use.

### Elections verified for this build
Two administrations changed since the September 4 pack and both were confirmed against primary coverage:

- **Costa Rica** — Laura Fernández (Pueblo Soberano) won the first round on 1 February 2026 with 48.53%, took office 8 May 2026, term to 2030. PPSO holds 31 of 57 legislative seats.
- **Colombia** — Abelardo de la Espriella (Defensores de la Patria) won the 21 June runoff with 49.7% against Iván Cepeda's 48.7% — roughly 250,000 votes. Sworn in 7 August 2026, term to 2030. His own movement contested no legislative seats.

---

## Naming note

The folder set covers Rapha's original seven markets. Colombia, the Dominican Republic and Guyana are not Central American, so the pack is named for the coverage team rather than the geography.

---

## Sources

Primary documents and named agency actions first. Full list on the **Sources** tab of the regional workbook.
