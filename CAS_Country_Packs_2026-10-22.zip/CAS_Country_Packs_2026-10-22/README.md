# CAS — Country Packs

**Two builds in one folder.** The CAS North set (seven markets) was built 10 September 2026 and is unchanged. The Andean set (Chile, Peru, Ecuador, Bolivia) was added 22 October 2026 using the same structure, method and grading.

INTERNAL — pending supervisory review. Factual reference only. Contains no recommendations, no suitability views and no positioning claims.

---

## Folder structure

```
CAS_Country_Packs_2026-10-22/
├── README.md
├── CAS_North_Regional_Overview_2026-09-10.pptx     ← start here for the northern seven
├── CAS_North_Regional_Overview_2026-09-10.xlsx
├── Andean_Regional_Overview_2026-10-22.pptx        ← start here for the Andean four
├── Andean_Regional_Overview_2026-10-22.xlsx
├── Panama/                 (2026-09-10)
├── Costa_Rica/             (2026-09-10)
├── Guatemala/              (2026-09-10)
├── El_Salvador/            (2026-09-10)
├── Dominican_Republic/     (2026-09-10)
├── Colombia/               (2026-09-10)
├── Guyana/                 (2026-09-10)
├── Chile/                  (2026-10-22)
├── Peru/                   (2026-10-22)
├── Ecuador/                (2026-10-22)
└── Bolivia/                (2026-10-22)
```

Each country folder holds two files:

| File | What it is |
|---|---|
| `<Country>_Brief_<date>.pptx` | ~26 slides. The orientation layer — read before a client conversation. |
| `<Country>_Workbook_<date>.xlsx` | 11–12 tabs, filterable. Carries the full text and is the working document. |

The country decks truncate long entries; the workbooks never do. When a slide says *"full text in the workbook,"* that is literal.

The Andean workbooks carry an additional **Sources** tab with a URL for every source used, so each number can be traced.

---

## What each deliverable answers

**Regional overviews** — the markets side by side on size, growth, inflation, currency regime and who governs them; the framing points that apply across the set; how wealth is organised; and the shared reference tables (ratings, calendar, traps, gaps, sources). Each overview workbook adds a consolidated **Group Directory** and **Access Map**, filterable by market and by confidence grade.

The two overviews are deliberately separate. The northern seven share a structural story (Panama as booking jurisdiction, remittance economies, dollarisation, family conglomerates with Panamanian holding structures). The Andean four do not share that story with them — or, entirely, with each other — and forcing them into one narrative would have produced a worse document. Where the two sets intersect (Colombia and the Andean three on the nuam exchange integration; Peruvian groups active in Bolivia and Ecuador), the Andean overview says so.

**Country packs** — the same questions in the same order for every market:

1. What an advisor needs to know
2. **Size, growth and inflation** — measured against the ECLAC regional benchmark
3. **What the economy is made of** — sector composition
4. **Who is in charge** — president, party, term, policy orientation, and governability
5. **Policy and macro framework** — currency regime, monetary policy, capital account, fiscal rules
6. What drives the economy — and separately, where the private wealth came from
7. Sectors and the principal names in each
8. The family groups, what they own, and what is live
9. Banking and wealth landscape, including who actually owns the local banks
10. Published institutional access map
11. Listed exposure, including the names that are traps
12. Dated events on the public record, plus practical notes
13. What we do not have

### The benchmark
Everything macro is stated against **ECLAC's August 2026 update** (*Estudio Económico de América Latina y el Caribe 2026*, 20 August 2026): Latin America and the Caribbean at **2.2%** real GDP growth for 2026 (2.4% in 2025, 2.5% projected for 2027); **South America 2.5%**; Central America excluding Cuba and Haiti 4.0%; median regional inflation near 3%.

ECLAC's own 2026 figures for the Andean four: Peru 3.2%, Ecuador 2.4%, Chile 1.6% (cut from 2.2% in April), Bolivia 0.5%. Two of the four sit above the regional figure and two below. This set is not the fast half of Latin America; it is the dispersion of it.

---

## Method

### Confidence grading
Every substantive row carries a grade.

| Grade | Meaning |
|---|---|
| **A** | Primary document or named agency action |
| **B** | Well-established public record, multiple independent sources |
| **C** | Widely reported, not independently verified — **check before client use** |
| **X** | Contradicted, stale or disputed — **do not use without checking** |

Rows graded X are shaded red in both the decks and the workbooks.

Distribution across the family groups: northern seven **14 A, 41 B, 14 C, 2 X** (71 groups); Andean four — see the Group_Directory tab of the Andean overview workbook; the counts are stated in the Gaps tab.

### What we deliberately do not assert
No personal banking relationships. No personal contact details. Nothing sourced from LinkedIn. None of it is public, and inferring it in a supervised document is a liability.

In its place: **the published institutional map** — board seats, apex business association roles, foundation leadership, endowed university positions and scholarships, exchange and issuer relationships, and named adviser, bookrunner, arranger and lender roles on disclosed transactions. All of it verifiable, citable, and durable through a compliance review.

### A note on GDP levels
Nominal GDP and GDP per capita in this pack are **indicative orders of magnitude, graded C**. They are correct for sizing a market against its neighbours and are **not** correct to quote to a decimal. Pull exact figures from the IMF WEO or the national statistics office before client use.

### Honest flagging over filled-in estimates
Where primary data was unavailable, the gap is documented with the exact source identifier needed to close it. Nothing has been filled with a modelled proxy. See the **Gaps** tab in every workbook.

### Known open items carried from the September build
Two sovereign rating rows in the CAS North overview — Dominican Republic and Colombia — were stale at the September build and remain marked X there. They have not been refreshed in this release; the September files are untouched.

---

## Naming note

The folder is now named for the coverage set rather than for CAS North alone, since the Andean four sit outside that team's geography. The original seven country folders and the CAS North overview keep their original file names and build date.

---

## Sources

Primary documents and named agency actions first. Full lists on the **Sources** tab of each overview workbook, and — for the Andean four — on the Sources tab of each country workbook with URLs.
