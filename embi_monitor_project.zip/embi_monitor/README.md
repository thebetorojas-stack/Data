# EMBI Global Monitor

A Python-based monitor for JPMorgan EMBI Global Diversified regional CSVs.
Drop a new CSV in, run one command, get a refreshed Excel where every region,
country, rating bucket, and Sov/Quasi cut is laid out for analysis. The
workbook updates **in place**; time-series sheets accumulate every run.

---

## Quick start

```bash
cd embi_monitor
python3 update.py "/path/to/JPM_EMBI_Global_regional_2026-04-27_xxxx.csv"
```

That's it. The script:
1. Parses the CSV (the multi-section JPM format — Headline / Region / Country / Rating / Sub-Rating / Sov-Quasi).
2. Stores a per-date pickle snapshot in `data/processed/` (idempotent — re-running with the same file just rewrites the snapshot).
3. Archives the raw CSV in `data/raw/`.
4. Rebuilds `EMBI_Monitor.xlsx` with **all sheets refreshed** to the latest snapshot, plus time-series sheets that have grown by one date.

### Weekly workflow

The convenient pattern: drop next week's download into the `inbox/` folder
and run with no arguments — the script picks it up automatically.

```bash
cp ~/Downloads/JPM_EMBI_Global_regional_2026-05-04_xxxx.csv embi_monitor/inbox/
cd embi_monitor && python3 update.py
```

### Other commands

```bash
python3 update.py --status         # show what's in the DB
python3 update.py --rebuild-only   # rebuild Excel without ingesting anything
python3 update.py --out custom.xlsx  # write to a custom path
python3 update.py file1.csv file2.csv  # ingest specific files
```

### Removing a snapshot

Just delete its pickle and rebuild:

```bash
rm embi_monitor/data/processed/2026-04-20.pkl
python3 update.py --rebuild-only
```

---

## Folder layout

```
embi_monitor/
├── update.py                    # CLI entry point
├── README.md
├── EMBI_Monitor.xlsx            # the deliverable (rebuilt each run)
├── inbox/                       # drop new CSVs here
├── data/
│   ├── raw/                     # archived source CSVs
│   └── processed/               # per-date pickles (the real DB)
└── embi_monitor/                # the package
    ├── parse.py                 # multi-section CSV parser
    ├── database.py              # append-only pickle store
    ├── report.py                # Excel report generator (all 15 sheets)
    └── style.py                 # openpyxl styling helpers
```

---

## What's in the workbook

| # | Sheet | Refresh | What it shows |
|---|---|---|---|
| 1 | **Cover** | snapshot | Headline KPIs, regional snapshot, top/bottom movers |
| 2 | **Regional** | snapshot | Every metric by region — returns, yield, spread, duration, ratings |
| 3 | **Country** | snapshot | Same wide table for ~70 countries, sorted by weight |
| 4 | **Weights** | snapshot | Country weights with cumulative %, data-bar visualisation |
| 5 | **Movers** | snapshot | Top 10 / Bottom 10 for Daily, MTD, YTD total return |
| 6 | **Rating** | snapshot | IG vs HY plus AA/A/BBB/BB/B/CCC/NR sub-buckets |
| 7 | **Sov_Quasi** | snapshot | Sovereign vs Quasi-Sov composite |
| 8 | **Region_x_Rating** | snapshot | Composition cross-tabs: within-region share, absolute weight, country count, weighted-avg YTD |
| 9 | **RV_Scorecards** | snapshot | Six rankings: STW/Dur, YTW/Dur, Z vs bucket median (cheap/rich), highest YTW, tightest spreads |
| 10 | **Spread_Analysis** | snapshot | Country list sorted by Z-spread with data-bar |
| 11 | **Yield_Analysis** | snapshot | Country list sorted by YTW with data-bar |
| 12 | **Time_Series** | **grows** | Headline + each region for every snapshot date — pivot/chart-ready |
| 13 | **Charts** | both | Regional returns bar, country weights bar, IG/HY pie, **index level line (≥2 dates)** |
| 14 | **Glossary** | static | Column & section definitions, usage tips |
| 15 | **Raw_Data** | grows | Tidy long format of every snapshot, every section — your pivot-table playground |

Conditional-format heatmaps are applied to every return column (red ↔ green
diverging at zero). Data bars on weight, yield, and Z-spread columns.

---

## Analysis ideas to explore

The data is rich — here are angles worth running once you have a few weeks
of history:

### Already in the workbook
- **Regional dispersion** — Regional sheet shows daily/MTD/YTD by region; heatmap surfaces leaders/laggards instantly.
- **Carry-per-duration** — RV_Scorecards #1 ranks countries by STW/Spread Duration; the highest-carry name per duration is your best risk-adjusted yield pickup.
- **Rating-relative cheapness** — RV_Scorecards #3/#4 shows Z-spread vs the median of each rating bucket; positive = cheap-vs-peers.
- **Composition drift** — Region × Rating cross-tab snapshots how a region's quality mix sits today; compare across runs to track upgrades / downgrades.

### Easy extensions (open `Raw_Data` and pivot, or extend `report.py`)
- **Week-on-week spread change** — diff Z-spread between most-recent two snapshots; biggest moves are your tactical signal.
- **Duration-weighted contribution to total return** — multiply spread return by spread duration weight to attribute regional return.
- **Volatility & Sharpe-ish metrics** — once you have ~12 weeks, compute realised vol on weekly total returns by region and country.
- **Concentration (HHI)** — Herfindahl on Mkt Cap % within a region tells you how many real names drive it.
- **Spread-curve betas** — regress country weekly Δ Z-spread on EMBIG Δ Z-spread for a country-beta to the market.
- **Rating migration** — track Average S&P Rating over time and flag changes; useful early-warning signal.
- **Yield-pickup vs IG benchmark** — country YTW minus IG composite YTW, normalized by spread duration.
- **Dispersion regimes** — cross-sectional std-dev of weekly Z-spread changes; widening dispersion = stress regime.
- **Quasi-vs-Sov premium** — track the Quasi/Sov spread differential; useful EM credit cycle indicator.
- **Region tilt vs benchmark** — your portfolio weight minus EMBI weight, contributed to relative return via region returns.

### Power user
- The `Raw_Data` sheet is one tidy long-format table with every snapshot.
  Pivot it freely: rows = SnapshotDate, columns = Section/Instrument,
  values = any metric. The Time_Series sheet is a curated subset focused on
  Headline + Regions for fast charting.

---

## Dependencies

Pure Python with two libraries (likely already on your machine):

```bash
pip install pandas openpyxl
```

That's it. No parquet, no numpy-on-fire, no extra packages.

---

## Notes / quirks of the JPM file

- Section markers live in column C (`Instrument`), not column A.
- Country names are uppercase in the source (e.g. `MONTENEGRO`); the parser
  title-cases them.
- A few names lack S&P ratings (e.g. Lebanon, Venezuela) — they fall into the
  `NR` bucket on rating-aware sheets.
- Mkt Cap % values for `Latin` (38%) + `Non Latin` (62%) sum to 100%, while
  the five sub-regions (Africa/Asia/Europe/Mid-East) sum to Non Latin.
  The parser stores all six region rows; pick whichever cut you prefer.
- Returns in the source are stored as percent values (1.52 means 1.52%, not
  0.0152). The workbook formats them with the literal `%` suffix.
