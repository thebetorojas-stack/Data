"""EMBI Global regional monitor."""
__version__ = "0.1.0"
