"""Excel report generator for EMBI monitor.

Builds a single workbook with ~16 sheets that are refreshed in-place each
time new snapshots are ingested. Time-series sheets accumulate; snapshot
sheets show the latest date.
"""
from __future__ import annotations
from pathlib import Path
import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill, Font, Border
from openpyxl.chart import BarChart, LineChart, PieChart, Reference, BarChart3D
from openpyxl.chart.label import DataLabelList

from .parse import rating_bucket
from .style import (
    title_font, header_font, body_font, header_fill, style_header_row,
    style_body, autosize, add_heatmap, add_databar, apply_format,
    BLUE_DARK, BLUE_MID, BLUE_LIGHT, GREY_HEADER, WHITE, GREEN, RED, YELLOW,
    BORDER, FMT_NUM_0, FMT_NUM_2, FMT_DEC, FMT_INT, FONT_NAME,
)


# ---- column groupings & display config -----------------------------------
RETURN_COLS = [
    ("Daily Change (%)", "Total D"),
    ("MTD Change (%)", "Total MTD"),
    ("YTD Change (%)", "Total YTD"),
    ("Spread Return Daily Change (%)", "Spread D"),
    ("Spread Return MTD Change (%)", "Spread MTD"),
    ("Spread Return YTD Change (%)", "Spread YTD"),
    ("UST Return Daily Change (%)", "UST D"),
    ("UST Return MTD Change (%)", "UST MTD"),
    ("UST Return YTD Change (%)", "UST YTD"),
]
RISK_COLS = [
    ("Spread Duration", "Spread Dur"),
    ("IR Duration to Worst", "IR Dur"),
    ("IR Convexity to Worst", "Convexity"),
    ("Avr. Life", "Avg Life"),
]
SPREAD_COLS = [
    ("STW (Trsy)", "STW (bps)"),
    ("Z Spread to Worst", "Z-Sprd (bps)"),
    ("Dur Wgt STW (Trsy)", "DurWgt STW"),
    ("Dur Wgt Z- Spread to Wrst", "DurWgt Z-Sprd"),
]
YIELD_COLS = [
    ("Yield to Worst", "YTW (%)"),
    ("Dur Wgt Yield Wrst", "DurWgt YTW"),
]
COMP_COLS = [
    ("Mkt Cap %", "Wt (%)"),
    ("Mkt Cap", "Mkt Cap ($)"),
    ("No. of Issues", "# Issues"),
    ("No. of Issuer", "# Issuers"),
]

PCT_FMT = '+0.00"%";-0.00"%";-'
WT_FMT = '0.00"%";(0.00"%");-'
PCT_YIELD_FMT = '0.00"%"'
BPS_FMT = '0;(0);-'
DEC2 = '0.00'
USD_BN_FMT = '$#,##0.0,,,"bn"'  # divide raw by 1e9 implicitly via format
INT_FMT = '#,##0'

# (column_name -> number_format) lookup -- includes both raw & display names
FMT_BY_COL = {}
for col, disp in RETURN_COLS:
    FMT_BY_COL[col] = PCT_FMT; FMT_BY_COL[disp] = PCT_FMT
for col, disp in RISK_COLS:
    FMT_BY_COL[col] = DEC2; FMT_BY_COL[disp] = DEC2
for col, disp in SPREAD_COLS:
    FMT_BY_COL[col] = BPS_FMT; FMT_BY_COL[disp] = BPS_FMT
for col, disp in YIELD_COLS:
    FMT_BY_COL[col] = PCT_YIELD_FMT; FMT_BY_COL[disp] = PCT_YIELD_FMT
FMT_BY_COL["Mkt Cap %"] = WT_FMT
FMT_BY_COL["Wt (%)"] = WT_FMT
FMT_BY_COL["Mkt Cap"] = USD_BN_FMT
FMT_BY_COL["Mkt Cap ($)"] = USD_BN_FMT
FMT_BY_COL["No. of Issues"] = INT_FMT
FMT_BY_COL["# Issues"] = INT_FMT
FMT_BY_COL["No. of Issuer"] = INT_FMT
FMT_BY_COL["# Issuers"] = INT_FMT
FMT_BY_COL["Index Level"] = '#,##0.00'

RATING_ORDER = ["AA", "A", "BBB", "BB", "B", "CCC", "NR"]


# ----------- helpers ------------------------------------------------------
def _write_table(ws, df, start_row, start_col=1, header_fill_color=BLUE_DARK,
                 number_formats=None, freeze=True, heatmap_cols=None):
    """Write a DataFrame to a worksheet with styling. Returns (last_row, last_col)."""
    n_rows, n_cols = df.shape
    # Header
    for j, col in enumerate(df.columns):
        cell = ws.cell(row=start_row, column=start_col + j, value=str(col))
    style_header_row(ws, start_row, n_cols, fill_color=header_fill_color)
    # Body
    for i, (_, row) in enumerate(df.iterrows()):
        for j, col in enumerate(df.columns):
            v = row[col]
            if pd.isna(v):
                v = None
            cell = ws.cell(row=start_row + 1 + i, column=start_col + j, value=v)
    last_row = start_row + n_rows
    style_body(ws, start_row + 1, last_row, n_cols)
    # Number formats
    fmts = number_formats or {}
    for j, col in enumerate(df.columns):
        col_letter = get_column_letter(start_col + j)
        fmt = fmts.get(col) or FMT_BY_COL.get(col)
        if fmt:
            apply_format(ws, start_row + 1, last_row, col_letter, fmt)
    # Heatmaps
    if heatmap_cols:
        for col in heatmap_cols:
            if col in df.columns:
                idx = list(df.columns).index(col)
                col_letter = get_column_letter(start_col + idx)
                add_heatmap(ws, start_row + 1, last_row, col_letter)
    if freeze:
        ws.freeze_panes = ws.cell(row=start_row + 1, column=start_col + 1)
    return last_row, n_cols


def _section_title(ws, row, text, span=8):
    cell = ws.cell(row=row, column=1, value=text)
    cell.font = title_font(size=14, color=BLUE_DARK)
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=span)
    cell.alignment = Alignment(horizontal="left", vertical="center")


def _drop_helpers(df):
    """Drop helper cols not meant for display."""
    return df.drop(columns=[c for c in ("Section", "SourceFile", "SnapshotDate", "IG_Flag") if c in df.columns])


def _select_cols(df, mapping):
    """Select & rename columns from the standard mappings (col_name -> display)."""
    cols = [c for c, _ in mapping if c in df.columns]
    out = df[cols].rename(columns={c: d for c, d in mapping if c in df.columns})
    return out


# ----------- sheet builders ----------------------------------------------
def _sheet_cover(wb, snap, headline_row, regional_df, latest_date):
    ws = wb.active
    ws.title = "Cover"
    ws["A1"] = "EMBI Global Monitor"
    ws["A1"].font = title_font(size=22, color=BLUE_DARK)
    ws["A2"] = f"Snapshot: {latest_date}"
    ws["A2"].font = body_font(size=12, color=BLUE_MID)
    ws["A3"] = f"Total snapshots in DB: {snap.get('n_dates', 1)}"
    ws["A3"].font = body_font(size=10)

    # Headline KPI block
    ws["A5"] = "Headline (EMBI Global)"
    ws["A5"].font = title_font(size=12)
    kpis = [
        ("Index Level",   headline_row.get("Index Level"),    "#,##0.00"),
        ("Daily Return",  headline_row.get("Daily Change (%)"), PCT_FMT),
        ("MTD Return",    headline_row.get("MTD Change (%)"),   PCT_FMT),
        ("YTD Return",    headline_row.get("YTD Change (%)"),   PCT_FMT),
        ("Yield to Worst", headline_row.get("Yield to Worst"),  PCT_YIELD_FMT),
        ("STW (bps)",     headline_row.get("STW (Trsy)"),      BPS_FMT),
        ("Z-Spread (bps)", headline_row.get("Z Spread to Worst"), BPS_FMT),
        ("Spread Duration", headline_row.get("Spread Duration"), DEC2),
        ("Avg Life",      headline_row.get("Avr. Life"),       DEC2),
        ("# Issues",      headline_row.get("No. of Issues"),   INT_FMT),
        ("# Issuers",     headline_row.get("No. of Issuer"),   INT_FMT),
        ("Avg S&P Rating", headline_row.get("Average S&P Rating"), None),
        ("Avg Moody",     headline_row.get("Average Moody Rating"), None),
        ("Avg Fitch",     headline_row.get("Average Fitch Rating"), None),
    ]
    r0 = 6
    for i, (lab, val, fmt) in enumerate(kpis):
        ws.cell(row=r0 + i, column=1, value=lab).font = body_font(bold=True)
        c = ws.cell(row=r0 + i, column=2, value=val if pd.notna(val) else None)
        c.font = body_font()
        if fmt:
            c.number_format = fmt
        ws.cell(row=r0 + i, column=1).fill = PatternFill("solid", start_color=BLUE_LIGHT, end_color=BLUE_LIGHT)
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 18

    # Regional snapshot
    r_block = r0 + len(kpis) + 2
    ws.cell(row=r_block - 1, column=1, value="Regional Snapshot").font = title_font(size=12)
    cols = [
        ("Instrument", "Region"),
        ("Mkt Cap %", "Wt (%)"),
        ("Daily Change (%)", "Daily"),
        ("MTD Change (%)", "MTD"),
        ("YTD Change (%)", "YTD"),
        ("Yield to Worst", "YTW"),
        ("STW (Trsy)", "STW (bps)"),
        ("Z Spread to Worst", "Z (bps)"),
        ("Spread Duration", "Sprd Dur"),
        ("Average S&P Rating", "S&P"),
    ]
    rd = regional_df.copy()
    rd = rd[[c for c, _ in cols]].rename(columns={c: d for c, d in cols})
    last, _ = _write_table(ws, rd, start_row=r_block, freeze=False,
                           number_formats={"Wt (%)": WT_FMT, "Daily": PCT_FMT, "MTD": PCT_FMT,
                                            "YTD": PCT_FMT, "YTW": PCT_YIELD_FMT,
                                            "STW (bps)": BPS_FMT, "Z (bps)": BPS_FMT,
                                            "Sprd Dur": DEC2},
                           heatmap_cols=["Daily", "MTD", "YTD"])
    autosize(ws)


def _sheet_regional(wb, region_df):
    ws = wb.create_sheet("Regional")
    ws["A1"] = "Regional Performance & Risk"
    ws["A1"].font = title_font(size=14)
    cols = [("Instrument", "Region"), ("Average S&P Rating", "S&P"),
            ("Average Moody Rating", "Moody"), ("Average Fitch Rating", "Fitch")]
    cols += COMP_COLS + RETURN_COLS + YIELD_COLS + SPREAD_COLS + RISK_COLS
    rd = region_df.copy()
    rd = rd[[c for c, _ in cols if c in rd.columns]]
    rd = rd.rename(columns={c: d for c, d in cols})
    heat = [d for c, d in RETURN_COLS if c in region_df.columns]
    last, ncols = _write_table(ws, rd, start_row=3, heatmap_cols=heat)
    autosize(ws, max_w=22)
    return last


def _sheet_country(wb, country_df):
    ws = wb.create_sheet("Country")
    ws["A1"] = "Country-Level Snapshot"
    ws["A1"].font = title_font(size=14)
    cols = [("Instrument", "Country"), ("Region", "Region"),
            ("Average S&P Rating", "S&P"), ("Average Moody Rating", "Moody"),
            ("Average Fitch Rating", "Fitch")]
    cols += COMP_COLS + RETURN_COLS + YIELD_COLS + SPREAD_COLS + RISK_COLS
    df = country_df.sort_values("Mkt Cap %", ascending=False).copy()
    df = df[[c for c, _ in cols if c in df.columns]]
    df = df.rename(columns={c: d for c, d in cols})
    heat = [d for c, d in RETURN_COLS if c in country_df.columns]
    _write_table(ws, df, start_row=3, heatmap_cols=heat)
    autosize(ws, max_w=22)


def _sheet_country_weights(wb, country_df):
    ws = wb.create_sheet("Weights")
    ws["A1"] = "Country Weights (sorted)"
    ws["A1"].font = title_font(size=14)
    df = country_df.sort_values("Mkt Cap %", ascending=False).reset_index(drop=True)
    df["Rank"] = df.index + 1
    df["Cumulative %"] = df["Mkt Cap %"].cumsum()
    out = df[["Rank", "Instrument", "Region", "Mkt Cap %", "Cumulative %",
              "Mkt Cap", "Average S&P Rating", "No. of Issues",
              "Yield to Worst", "STW (Trsy)", "Spread Duration", "YTD Change (%)"]]
    out = out.rename(columns={
        "Instrument": "Country", "Mkt Cap %": "Wt (%)", "Mkt Cap": "Mkt Cap ($)",
        "Average S&P Rating": "S&P", "No. of Issues": "# Issues",
        "Yield to Worst": "YTW", "STW (Trsy)": "STW (bps)",
        "Spread Duration": "Sprd Dur", "YTD Change (%)": "YTD",
    })
    last, _ = _write_table(ws, out, start_row=3,
                           number_formats={"Wt (%)": WT_FMT, "Cumulative %": WT_FMT,
                                            "Mkt Cap ($)": USD_BN_FMT, "# Issues": INT_FMT,
                                            "YTW": PCT_YIELD_FMT, "STW (bps)": BPS_FMT,
                                            "Sprd Dur": DEC2, "YTD": PCT_FMT,
                                            "Rank": INT_FMT},
                           heatmap_cols=["YTD"])
    # Data bar on weight
    add_databar(ws, 4, last, "D")
    autosize(ws)


def _movers_block(ws, df, ret_col, label, start_col, n=10):
    """Write a Top-N + Bottom-N block side-by-side starting at start_col."""
    sub = df.dropna(subset=[ret_col]).copy()
    top = sub.sort_values(ret_col, ascending=False).head(n)
    bot = sub.sort_values(ret_col, ascending=True).head(n)
    blocks = [("Top " + str(n), top), ("Bottom " + str(n), bot)]
    cur = start_col
    for title, frame in blocks:
        out = frame[["Instrument", "Region", "Mkt Cap %", ret_col, "Average S&P Rating"]].copy()
        out = out.rename(columns={"Instrument": "Country", "Mkt Cap %": "Wt", ret_col: label,
                                    "Average S&P Rating": "S&P"})
        ws.cell(row=2, column=cur, value=f"{title} – {label}").font = title_font(size=11)
        _write_table(ws, out, start_row=3, start_col=cur,
                     number_formats={"Wt": WT_FMT, label: PCT_FMT},
                     heatmap_cols=[label], freeze=False)
        cur += len(out.columns) + 1
    return cur


def _sheet_movers(wb, country_df):
    ws = wb.create_sheet("Movers")
    ws["A1"] = "Top / Bottom Country Movers"
    ws["A1"].font = title_font(size=14)
    # Three blocks rendered top-to-bottom for readability, each row offset
    pairs = [
        ("Daily Change (%)", "Daily"),
        ("MTD Change (%)", "MTD"),
        ("YTD Change (%)", "YTD"),
    ]
    cur_row = 1
    cur_top = 2
    sec_row = 2
    next_row = 2
    # We'll stack vertically.
    base_row = 2
    for ret_col, label in pairs:
        ws.cell(row=base_row, column=1, value=f"{label} Return").font = title_font(size=12)
        # top
        sub = country_df.dropna(subset=[ret_col]).copy()
        top = sub.sort_values(ret_col, ascending=False).head(10).copy()
        bot = sub.sort_values(ret_col, ascending=True).head(10).copy()
        for title, frame, col_offset in [("Top 10", top, 1), ("Bottom 10", bot, 8)]:
            out = frame[["Instrument", "Region", "Mkt Cap %", ret_col, "Average S&P Rating"]]
            out = out.rename(columns={"Instrument": "Country", "Mkt Cap %": "Wt",
                                       ret_col: label, "Average S&P Rating": "S&P"})
            ws.cell(row=base_row + 1, column=col_offset,
                    value=f"{title} – {label}").font = title_font(size=11)
            _write_table(ws, out, start_row=base_row + 2, start_col=col_offset,
                         number_formats={"Wt": WT_FMT, label: PCT_FMT},
                         heatmap_cols=[label], freeze=False)
        base_row += 14
    autosize(ws, max_w=20)


def _sheet_rating(wb, rating_df, subrating_df):
    ws = wb.create_sheet("Rating")
    ws["A1"] = "Rating Bucket Performance"
    ws["A1"].font = title_font(size=14)

    # Block 1: IG vs HY
    ws["A3"] = "Investment Grade vs Non-Investment Grade"
    ws["A3"].font = title_font(size=12)
    cols = [("Instrument", "Bucket")] + COMP_COLS + RETURN_COLS + YIELD_COLS + SPREAD_COLS + RISK_COLS
    rd = rating_df[[c for c, _ in cols if c in rating_df.columns]].rename(
        columns={c: d for c, d in cols})
    heat = [d for c, d in RETURN_COLS if c in rating_df.columns]
    last1, _ = _write_table(ws, rd, start_row=4, heatmap_cols=heat, freeze=False)

    # Block 2: Sub buckets
    sb_row = last1 + 3
    ws.cell(row=sb_row, column=1, value="By S&P Sub-Bucket").font = title_font(size=12)
    sd = subrating_df.copy()
    # order
    sd["__order"] = sd["Instrument"].map({"AAA": 0, "AA": 1, "A": 2, "BBB": 3,
                                            "BB": 4, "B": 5, "CCC": 6, "CC": 7,
                                            "C": 8, "NR": 9})
    sd = sd.sort_values("__order").drop(columns="__order")
    sd = sd[[c for c, _ in cols if c in sd.columns]].rename(
        columns={c: d for c, d in cols})
    _write_table(ws, sd, start_row=sb_row + 1, heatmap_cols=heat, freeze=False)
    autosize(ws, max_w=22)


def _sheet_sov_quasi(wb, sq_df):
    ws = wb.create_sheet("Sov_Quasi")
    ws["A1"] = "Sovereign vs Quasi-Sovereign"
    ws["A1"].font = title_font(size=14)
    cols = [("Instrument", "Type")] + COMP_COLS + RETURN_COLS + YIELD_COLS + SPREAD_COLS + RISK_COLS
    sd = sq_df[[c for c, _ in cols if c in sq_df.columns]].rename(
        columns={c: d for c, d in cols})
    heat = [d for c, d in RETURN_COLS if c in sq_df.columns]
    _write_table(ws, sd, start_row=3, heatmap_cols=heat, freeze=False)
    autosize(ws, max_w=22)


def _sheet_region_x_rating(wb, country_df):
    """Cross-tab: rating bucket weight & count by region."""
    ws = wb.create_sheet("Region_x_Rating")
    ws["A1"] = "Region × Rating Composition"
    ws["A1"].font = title_font(size=14)
    df = country_df.copy()
    df["Bucket"] = df["Average S&P Rating"].map(rating_bucket)

    # Pivot 1: weight share within region (% of region mkt cap)
    pivot_w = df.pivot_table(index="Region", columns="Bucket",
                              values="Mkt Cap %", aggfunc="sum", fill_value=0)
    pivot_w = pivot_w.reindex(columns=[c for c in RATING_ORDER if c in pivot_w.columns])
    # Convert to share-of-region (rows sum to ~100%)
    pivot_w_share = pivot_w.div(pivot_w.sum(axis=1), axis=0) * 100
    pivot_w_share["Total"] = pivot_w_share.sum(axis=1)
    # Also keep absolute % of EMBI
    pivot_w["Total Wt (%)"] = pivot_w.sum(axis=1)

    # Pivot 2: country count
    pivot_n = df.pivot_table(index="Region", columns="Bucket",
                              values="Instrument", aggfunc="count", fill_value=0)
    pivot_n = pivot_n.reindex(columns=[c for c in RATING_ORDER if c in pivot_n.columns])
    pivot_n["Total"] = pivot_n.sum(axis=1)

    # Pivot 3: weighted-average YTD by region & bucket
    def wavg(g):
        v = g["YTD Change (%)"]; w = g["Mkt Cap %"]
        return np.average(v.dropna(), weights=w.loc[v.dropna().index]) if v.notna().any() else np.nan
    rows = []
    for (r, b), g in df.groupby(["Region", "Bucket"]):
        rows.append({"Region": r, "Bucket": b, "YTD": wavg(g)})
    pivot_ytd = (pd.DataFrame(rows)
                 .pivot_table(index="Region", columns="Bucket", values="YTD"))
    pivot_ytd = pivot_ytd.reindex(columns=[c for c in RATING_ORDER if c in pivot_ytd.columns])

    # Write three blocks
    def _write_pivot(p, start_row, title, fmt, heat=False):
        ws.cell(row=start_row, column=1, value=title).font = title_font(size=12)
        out = p.reset_index()
        last, _ = _write_table(ws, out, start_row=start_row + 1, freeze=False)
        # Apply format to all numeric columns (skip first index col)
        for j, col in enumerate(out.columns):
            if j == 0: continue
            letter = get_column_letter(1 + j)
            apply_format(ws, start_row + 2, last, letter, fmt)
            if heat:
                add_heatmap(ws, start_row + 2, last, letter,
                            mode="diverging" if "%" in fmt or '"%"' in fmt else "min_max")
        return last

    r1 = _write_pivot(pivot_w_share, 3, "Within-region weight share (%)", WT_FMT, heat=True)
    r2 = _write_pivot(pivot_w, r1 + 3, "Absolute weight (% of total EMBI)", WT_FMT, heat=True)
    r3 = _write_pivot(pivot_n, r2 + 3, "Country count", INT_FMT, heat=False)
    _write_pivot(pivot_ytd, r3 + 3, "Weighted-avg YTD return (%)", PCT_FMT, heat=True)
    autosize(ws, max_w=18)


def _sheet_rv_scorecards(wb, country_df):
    ws = wb.create_sheet("RV_Scorecards")
    ws["A1"] = "Relative-Value Scorecards"
    ws["A1"].font = title_font(size=14)

    df = country_df.copy()
    df["Bucket"] = df["Average S&P Rating"].map(rating_bucket)
    df["STW/Dur"] = df["STW (Trsy)"] / df["Spread Duration"].replace(0, np.nan)
    df["YTW/Dur"] = df["Yield to Worst"] / df["Spread Duration"].replace(0, np.nan)
    # Bucket-relative spread (Z-spread vs bucket median) — positive = cheap (wider)
    df["Bucket Z-median"] = df.groupby("Bucket")["Z Spread to Worst"].transform("median")
    df["Z vs bucket median"] = df["Z Spread to Worst"] - df["Bucket Z-median"]
    df["Bucket YTW-median"] = df.groupby("Bucket")["Yield to Worst"].transform("median")
    df["YTW vs bucket median"] = df["Yield to Worst"] - df["Bucket YTW-median"]

    base_cols = ["Instrument", "Region", "Bucket", "Mkt Cap %",
                 "Yield to Worst", "STW (Trsy)", "Z Spread to Worst", "Spread Duration",
                 "STW/Dur", "YTW/Dur",
                 "Z vs bucket median", "YTW vs bucket median",
                 "YTD Change (%)"]
    rename = {"Instrument": "Country", "Mkt Cap %": "Wt (%)",
              "Yield to Worst": "YTW (%)", "STW (Trsy)": "STW (bps)",
              "Z Spread to Worst": "Z (bps)", "Spread Duration": "Sprd Dur",
              "YTD Change (%)": "YTD"}
    fmt_map = {"Wt (%)": WT_FMT, "YTW (%)": PCT_YIELD_FMT, "STW (bps)": BPS_FMT,
                "Z (bps)": BPS_FMT, "Sprd Dur": DEC2, "STW/Dur": DEC2,
                "YTW/Dur": DEC2, "Z vs bucket median": BPS_FMT,
                "YTW vs bucket median": '+0.00"%";-0.00"%";-', "YTD": PCT_FMT}

    blocks = [
        ("Carry per unit duration  (highest STW/Dur = best carry)",
            df.dropna(subset=["STW/Dur"]).sort_values("STW/Dur", ascending=False).head(15)),
        ("Yield per unit duration  (highest YTW/Dur)",
            df.dropna(subset=["YTW/Dur"]).sort_values("YTW/Dur", ascending=False).head(15)),
        ("Cheapest vs rating bucket  (positive Z vs median = wider than peers)",
            df.dropna(subset=["Z vs bucket median"]).sort_values("Z vs bucket median", ascending=False).head(15)),
        ("Richest vs rating bucket",
            df.dropna(subset=["Z vs bucket median"]).sort_values("Z vs bucket median", ascending=True).head(15)),
        ("Highest YTW (raw)",
            df.dropna(subset=["Yield to Worst"]).sort_values("Yield to Worst", ascending=False).head(15)),
        ("Tightest spreads (raw)",
            df.dropna(subset=["STW (Trsy)"]).sort_values("STW (Trsy)", ascending=True).head(15)),
    ]

    cur = 3
    for title, frame in blocks:
        ws.cell(row=cur, column=1, value=title).font = title_font(size=12)
        out = frame[base_cols].rename(columns=rename)
        last, _ = _write_table(ws, out, start_row=cur + 1,
                                number_formats=fmt_map,
                                heatmap_cols=["YTD"], freeze=False)
        cur = last + 3
    autosize(ws, max_w=20)


def _sheet_spread(wb, country_df):
    ws = wb.create_sheet("Spread_Analysis")
    ws["A1"] = "Spread Analysis (sorted by Z-Spread)"
    ws["A1"].font = title_font(size=14)
    df = country_df.dropna(subset=["Z Spread to Worst"]).sort_values(
        "Z Spread to Worst", ascending=False)
    cols = ["Instrument", "Region", "Average S&P Rating", "Mkt Cap %",
            "STW (Trsy)", "Z Spread to Worst", "Spread Duration",
            "Yield to Worst", "Avr. Life", "Spread Return YTD Change (%)",
            "YTD Change (%)"]
    out = df[cols].rename(columns={
        "Instrument": "Country", "Average S&P Rating": "S&P",
        "Mkt Cap %": "Wt (%)", "STW (Trsy)": "STW (bps)",
        "Z Spread to Worst": "Z (bps)", "Spread Duration": "Sprd Dur",
        "Yield to Worst": "YTW", "Avr. Life": "Avg Life",
        "Spread Return YTD Change (%)": "Sprd Ret YTD",
        "YTD Change (%)": "Total YTD",
    })
    fmt = {"Wt (%)": WT_FMT, "STW (bps)": BPS_FMT, "Z (bps)": BPS_FMT,
            "Sprd Dur": DEC2, "YTW": PCT_YIELD_FMT, "Avg Life": DEC2,
            "Sprd Ret YTD": PCT_FMT, "Total YTD": PCT_FMT}
    last, _ = _write_table(ws, out, start_row=3, number_formats=fmt,
                            heatmap_cols=["Sprd Ret YTD", "Total YTD"])
    add_databar(ws, 4, last, get_column_letter(list(out.columns).index("Z (bps)") + 1))
    autosize(ws, max_w=20)


def _sheet_yield(wb, country_df):
    ws = wb.create_sheet("Yield_Analysis")
    ws["A1"] = "Yield Analysis (sorted by YTW)"
    ws["A1"].font = title_font(size=14)
    df = country_df.dropna(subset=["Yield to Worst"]).sort_values(
        "Yield to Worst", ascending=False)
    cols = ["Instrument", "Region", "Average S&P Rating", "Mkt Cap %",
            "Yield to Worst", "Dur Wgt Yield Wrst", "Spread Duration",
            "STW (Trsy)", "Z Spread to Worst", "Avr. Life",
            "YTD Change (%)"]
    out = df[cols].rename(columns={
        "Instrument": "Country", "Average S&P Rating": "S&P",
        "Mkt Cap %": "Wt (%)", "Yield to Worst": "YTW",
        "Dur Wgt Yield Wrst": "DurWgt YTW", "Spread Duration": "Sprd Dur",
        "STW (Trsy)": "STW (bps)", "Z Spread to Worst": "Z (bps)",
        "Avr. Life": "Avg Life", "YTD Change (%)": "YTD",
    })
    fmt = {"Wt (%)": WT_FMT, "YTW": PCT_YIELD_FMT, "DurWgt YTW": PCT_YIELD_FMT,
            "Sprd Dur": DEC2, "STW (bps)": BPS_FMT, "Z (bps)": BPS_FMT,
            "Avg Life": DEC2, "YTD": PCT_FMT}
    last, _ = _write_table(ws, out, start_row=3, number_formats=fmt,
                            heatmap_cols=["YTD"])
    add_databar(ws, 4, last, get_column_letter(list(out.columns).index("YTW") + 1))
    autosize(ws, max_w=20)


def _sheet_time_series(wb, master_df):
    ws = wb.create_sheet("Time_Series")
    ws["A1"] = "Headline & Regional Time Series"
    ws["A1"].font = title_font(size=14)
    keep_sections = ["Headline", "Region"]
    df = master_df[master_df["Section"].isin(keep_sections)].copy()
    df["Series"] = df.apply(
        lambda r: "EMBI Global" if r["Section"] == "Headline" else r["Instrument"],
        axis=1,
    )
    cols = ["SnapshotDate", "Series", "Index Level", "Mkt Cap %",
            "Daily Change (%)", "MTD Change (%)", "YTD Change (%)",
            "Yield to Worst", "STW (Trsy)", "Z Spread to Worst",
            "Spread Duration", "Avr. Life",
            "Average S&P Rating", "Average Moody Rating", "Average Fitch Rating",
            "No. of Issues", "No. of Issuer"]
    df = df[[c for c in cols if c in df.columns]]
    df = df.sort_values(["SnapshotDate", "Series"])
    rename = {"SnapshotDate": "Date", "Index Level": "Index",
              "Mkt Cap %": "Wt (%)", "Daily Change (%)": "Daily",
              "MTD Change (%)": "MTD", "YTD Change (%)": "YTD",
              "Yield to Worst": "YTW", "STW (Trsy)": "STW (bps)",
              "Z Spread to Worst": "Z (bps)", "Spread Duration": "Sprd Dur",
              "Avr. Life": "Avg Life", "Average S&P Rating": "S&P",
              "Average Moody Rating": "Moody", "Average Fitch Rating": "Fitch",
              "No. of Issues": "# Issues", "No. of Issuer": "# Issuers"}
    df = df.rename(columns=rename)
    fmt = {"Index": "#,##0.00", "Wt (%)": WT_FMT, "Daily": PCT_FMT,
            "MTD": PCT_FMT, "YTD": PCT_FMT, "YTW": PCT_YIELD_FMT,
            "STW (bps)": BPS_FMT, "Z (bps)": BPS_FMT, "Sprd Dur": DEC2,
            "Avg Life": DEC2, "# Issues": INT_FMT, "# Issuers": INT_FMT,
            "Date": "yyyy-mm-dd"}
    _write_table(ws, df, start_row=3, number_formats=fmt,
                  heatmap_cols=["Daily", "MTD", "YTD"])
    autosize(ws, max_w=20)


def _sheet_charts(wb, region_df, country_df, rating_df, master_df):
    ws = wb.create_sheet("Charts")
    ws["A1"] = "Visual Snapshots"
    ws["A1"].font = title_font(size=14)

    # ---- Chart 1: Regional YTD bar
    ws["A3"] = "Regional Total Returns (%)"
    ws["A3"].font = title_font(size=12)
    rd = region_df[["Instrument", "Daily Change (%)", "MTD Change (%)", "YTD Change (%)"]].copy()
    rd = rd.rename(columns={"Instrument": "Region", "Daily Change (%)": "Daily",
                              "MTD Change (%)": "MTD", "YTD Change (%)": "YTD"})
    start_row = 4
    for j, c in enumerate(rd.columns):
        ws.cell(row=start_row, column=1 + j, value=c).font = header_font(color=WHITE)
        ws.cell(row=start_row, column=1 + j).fill = header_fill(BLUE_DARK)
    for i, (_, row) in enumerate(rd.iterrows()):
        for j, c in enumerate(rd.columns):
            ws.cell(row=start_row + 1 + i, column=1 + j, value=row[c])
    end_row = start_row + len(rd)
    chart = BarChart()
    chart.type = "col"
    chart.title = "Regional Returns"
    chart.y_axis.title = "Return (%)"
    chart.x_axis.title = "Region"
    data = Reference(ws, min_col=2, min_row=start_row, max_col=4, max_row=end_row)
    cats = Reference(ws, min_col=1, min_row=start_row + 1, max_row=end_row)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)
    chart.height = 9; chart.width = 18
    ws.add_chart(chart, "F3")

    # ---- Chart 2: Top 20 country weights bar
    ws["A20"] = "Top 20 Country Weights"
    ws["A20"].font = title_font(size=12)
    cw = country_df[["Instrument", "Mkt Cap %"]].sort_values("Mkt Cap %", ascending=False).head(20)
    cw = cw.rename(columns={"Instrument": "Country", "Mkt Cap %": "Wt (%)"})
    sr = 21
    for j, c in enumerate(cw.columns):
        ws.cell(row=sr, column=1 + j, value=c).font = header_font(color=WHITE)
        ws.cell(row=sr, column=1 + j).fill = header_fill(BLUE_DARK)
    for i, (_, row) in enumerate(cw.iterrows()):
        for j, c in enumerate(cw.columns):
            ws.cell(row=sr + 1 + i, column=1 + j, value=row[c])
    er = sr + len(cw)
    ch2 = BarChart()
    ch2.type = "bar"
    ch2.title = "Top 20 Country Weights"
    data = Reference(ws, min_col=2, min_row=sr, max_row=er)
    cats = Reference(ws, min_col=1, min_row=sr + 1, max_row=er)
    ch2.add_data(data, titles_from_data=True)
    ch2.set_categories(cats)
    ch2.height = 14; ch2.width = 18
    ws.add_chart(ch2, "F20")

    # ---- Chart 3: IG vs HY weight pie (using Mkt Cap %)
    ws["A45"] = "Investment Grade vs HY Weight"
    ws["A45"].font = title_font(size=12)
    rb = rating_df[["Instrument", "Mkt Cap %"]].rename(
        columns={"Instrument": "Bucket", "Mkt Cap %": "Wt (%)"})
    sr = 46
    for j, c in enumerate(rb.columns):
        ws.cell(row=sr, column=1 + j, value=c).font = header_font(color=WHITE)
        ws.cell(row=sr, column=1 + j).fill = header_fill(BLUE_DARK)
    for i, (_, row) in enumerate(rb.iterrows()):
        for j, c in enumerate(rb.columns):
            ws.cell(row=sr + 1 + i, column=1 + j, value=row[c])
    er = sr + len(rb)
    pie = PieChart()
    pie.title = "IG vs HY"
    data = Reference(ws, min_col=2, min_row=sr, max_row=er)
    cats = Reference(ws, min_col=1, min_row=sr + 1, max_row=er)
    pie.add_data(data, titles_from_data=True)
    pie.set_categories(cats)
    pie.dataLabels = DataLabelList(showPercent=True)
    pie.height = 9; pie.width = 12
    ws.add_chart(pie, "F45")

    # ---- Chart 4: Time series of EMBI Global Index Level (only if multiple dates)
    n_dates = master_df["SnapshotDate"].nunique()
    if n_dates > 1:
        ws["A60"] = "EMBI Global Index Level – History"
        ws["A60"].font = title_font(size=12)
        ts = master_df[master_df["Section"] == "Headline"][["SnapshotDate", "Index Level"]].sort_values("SnapshotDate")
        sr = 61
        for j, c in enumerate(["Date", "Index Level"]):
            ws.cell(row=sr, column=1 + j, value=c).font = header_font(color=WHITE)
            ws.cell(row=sr, column=1 + j).fill = header_fill(BLUE_DARK)
        for i, (_, row) in enumerate(ts.iterrows()):
            ws.cell(row=sr + 1 + i, column=1, value=row["SnapshotDate"]).number_format = "yyyy-mm-dd"
            ws.cell(row=sr + 1 + i, column=2, value=row["Index Level"])
        er = sr + len(ts)
        ln = LineChart()
        ln.title = "EMBI Global Index"
        ln.y_axis.title = "Index Level"
        data = Reference(ws, min_col=2, min_row=sr, max_row=er)
        cats = Reference(ws, min_col=1, min_row=sr + 1, max_row=er)
        ln.add_data(data, titles_from_data=True)
        ln.set_categories(cats)
        ln.height = 9; ln.width = 18
        ws.add_chart(ln, "F60")


def _sheet_glossary(wb):
    ws = wb.create_sheet("Glossary")
    ws["A1"] = "Glossary & How to Use"
    ws["A1"].font = title_font(size=16)
    rows = [
        ("Section", "Description"),
        ("Headline", "Top-level EMBI Global aggregate."),
        ("Region", "Africa / Asia / Europe / Latin / Middle East / Non Latin."),
        ("Country", "Issuer-country index level."),
        ("Rating", "Investment Grade vs Non-Investment Grade composite."),
        ("SubRating", "Granular S&P bucket (AA, A, BBB, BB, B, CCC, NR)."),
        ("SovQuasi", "Sovereign vs Quasi-Sovereign split."),
        ("", ""),
        ("Metric", "Notes"),
        ("Index Level", "Total-return index, base 100 at JPM inception."),
        ("Daily/MTD/YTD Change (%)", "Total return for the period (price + coupon + UST + spread)."),
        ("Spread Return", "Return component attributable to spread changes."),
        ("UST Return", "Return component attributable to underlying Treasury moves."),
        ("STW (Trsy)", "Spread to Worst over Treasuries, in bps."),
        ("Z Spread to Worst", "Z-spread to maturity / call worst, bps."),
        ("Yield to Worst", "Yield assuming worst-case redemption."),
        ("Spread Duration", "Sensitivity of price to spread changes (yrs)."),
        ("IR Duration to Worst", "Sensitivity to interest-rate changes (yrs)."),
        ("Avg Life", "Weighted average life to maturity (yrs)."),
        ("Mkt Cap %", "Index weight (free-float adjusted)."),
        ("# Issues / # Issuers", "Bond count and unique issuer count."),
        ("Dur Wgt …", "Duration-weighted version of the metric."),
        ("", ""),
        ("How to update", ""),
        ("1.", "Drop new JPM_EMBI_Global_regional_<date>_<id>.csv files into data/raw/ "
              "(or anywhere), then run: python update.py"),
        ("2.", "The script ingests new dates (idempotent), rebuilds the workbook in place, "
              "and time-series sheets accumulate."),
        ("3.", "Rerun anytime; old snapshots remain intact."),
        ("", ""),
        ("Tips", ""),
        ("Filter", "Use Excel's filter on Country / Rating sheets to slice by region or rating."),
        ("Pivot", "The Raw_Data sheet is pivot-friendly long-format; build your own analyses."),
        ("RV", "RV_Scorecards ranks countries by carry-per-duration and rating-bucket-relative spread."),
    ]
    for i, (a, b) in enumerate(rows, start=1):
        ws.cell(row=i + 1, column=1, value=a).font = body_font(bold=(b != "" and a not in ("1.", "2.", "3.", "Filter", "Pivot", "RV")))
        ws.cell(row=i + 1, column=2, value=b).font = body_font()
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 100


def _sheet_raw_data(wb, master_df):
    ws = wb.create_sheet("Raw_Data")
    ws["A1"] = "Tidy long-format dataset (every snapshot, every section)"
    ws["A1"].font = title_font(size=14)
    df = master_df.copy()
    # Reorder a bit
    front = ["SnapshotDate", "Section", "Bam Id", "Instrument", "Region",
             "Average S&P Rating", "Average Moody Rating", "Average Fitch Rating", "IG_Flag"]
    rest = [c for c in df.columns if c not in front]
    df = df[[c for c in front if c in df.columns] + rest]
    _write_table(ws, df, start_row=3, freeze=True)
    autosize(ws, max_w=22)


# ---- main entry ----------------------------------------------------------
def build_workbook(db, out_path: str | Path) -> Path:
    """Build (or rebuild) the master Excel workbook."""
    out_path = Path(out_path)
    master = db.load_master()
    latest = db.latest_date()
    snap_df = db.load_snapshot(latest)

    # Group rows by section for the latest snapshot
    sections = {s: snap_df[snap_df["Section"] == s].copy() for s in
                ("Headline", "Region", "Country", "Rating", "SubRating", "SovQuasi")}

    headline_row = sections["Headline"].iloc[0].to_dict() if len(sections["Headline"]) else {}

    wb = Workbook()
    _sheet_cover(wb, {"n_dates": master["SnapshotDate"].nunique()},
                 headline_row, sections["Region"], latest)
    _sheet_regional(wb, sections["Region"])
    _sheet_country(wb, sections["Country"])
    _sheet_country_weights(wb, sections["Country"])
    _sheet_movers(wb, sections["Country"])
    _sheet_rating(wb, sections["Rating"], sections["SubRating"])
    _sheet_sov_quasi(wb, sections["SovQuasi"])
    _sheet_region_x_rating(wb, sections["Country"])
    _sheet_rv_scorecards(wb, sections["Country"])
    _sheet_spread(wb, sections["Country"])
    _sheet_yield(wb, sections["Country"])
    _sheet_time_series(wb, master)
    _sheet_charts(wb, sections["Region"], sections["Country"], sections["Rating"], master)
    _sheet_glossary(wb)
    _sheet_raw_data(wb, master)

    wb.save(out_path)
    return out_path
