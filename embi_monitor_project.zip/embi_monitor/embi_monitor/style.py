"""Shared openpyxl styling helpers."""
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.formatting.rule import ColorScaleRule, DataBarRule
from openpyxl.utils import get_column_letter

FONT_NAME = "Arial"

# Colours (institutional dark-blue palette)
BLUE_DARK = "1F3864"
BLUE_MID = "2E5597"
BLUE_LIGHT = "D9E1F2"
GREY_HEADER = "F2F2F2"
GREEN = "63BE7B"
WHITE = "FFFFFF"
RED = "F8696B"
YELLOW = "FFEB84"

THIN = Side(border_style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def title_font(size=16, bold=True, color=BLUE_DARK):
    return Font(name=FONT_NAME, size=size, bold=bold, color=color)


def header_font(color=WHITE, bold=True, size=10):
    return Font(name=FONT_NAME, size=size, bold=bold, color=color)


def body_font(size=10, bold=False, color="000000"):
    return Font(name=FONT_NAME, size=size, bold=bold, color=color)


def header_fill(color=BLUE_DARK):
    return PatternFill("solid", start_color=color, end_color=color)


def style_header_row(ws, row, n_cols, fill_color=BLUE_DARK, font_color=WHITE):
    for c in range(1, n_cols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = header_font(color=font_color)
        cell.fill = header_fill(fill_color)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER


def style_body(ws, first_row, last_row, n_cols, alt_shade=True):
    for r in range(first_row, last_row + 1):
        for c in range(1, n_cols + 1):
            cell = ws.cell(row=r, column=c)
            cell.font = body_font()
            cell.border = BORDER
            if alt_shade and (r - first_row) % 2 == 1:
                cell.fill = PatternFill("solid", start_color=GREY_HEADER, end_color=GREY_HEADER)


def autosize(ws, min_w=10, max_w=28):
    for col_idx, col_cells in enumerate(ws.columns, start=1):
        letter = get_column_letter(col_idx)
        try:
            length = max((len(str(c.value)) if c.value is not None else 0) for c in col_cells)
        except ValueError:
            length = min_w
        ws.column_dimensions[letter].width = max(min_w, min(max_w, length + 2))


def add_heatmap(ws, first_row, last_row, col_letter, mode="diverging"):
    """Add a colour-scale conditional format to a column range."""
    rng = f"{col_letter}{first_row}:{col_letter}{last_row}"
    if mode == "diverging":
        rule = ColorScaleRule(
            start_type="num", start_value=-5, start_color=RED,
            mid_type="num", mid_value=0, mid_color=WHITE,
            end_type="num", end_value=5, end_color=GREEN,
        )
    elif mode == "min_max":
        rule = ColorScaleRule(
            start_type="min", start_color=RED,
            mid_type="percentile", mid_value=50, mid_color=WHITE,
            end_type="max", end_color=GREEN,
        )
    else:  # ascending green-only (good for weights, big = darker green)
        rule = ColorScaleRule(
            start_type="min", start_color=WHITE,
            end_type="max", end_color=GREEN,
        )
    ws.conditional_formatting.add(rng, rule)


def add_databar(ws, first_row, last_row, col_letter, color=BLUE_MID):
    rng = f"{col_letter}{first_row}:{col_letter}{last_row}"
    rule = DataBarRule(start_type="min", end_type="max", color=color, showValue=True)
    ws.conditional_formatting.add(rng, rule)


# Number formats
FMT_PCT_2 = "0.00%;(0.00%);-"
FMT_PCT_1 = "0.0%;(0.0%);-"
FMT_NUM_2 = "#,##0.00;(#,##0.00);-"
FMT_NUM_0 = "#,##0;(#,##0);-"
FMT_INT = "#,##0"
FMT_BPS = "0;(0);-"  # for spread bps
FMT_DEC = "0.00"
FMT_DATE = "yyyy-mm-dd"


def apply_format(ws, first_row, last_row, col_letter, fmt):
    for r in range(first_row, last_row + 1):
        ws[f"{col_letter}{r}"].number_format = fmt
