"""Append-only pickle-based master database for EMBI snapshots.

One pickle file per snapshot date keeps the store simple and bullet-proof
under re-runs. The combined view is materialised on-demand via load_master().
Pickle is used (not parquet) so the only runtime dependency is pandas.
"""
from __future__ import annotations
from pathlib import Path
import shutil
import pandas as pd
from .parse import parse_csv


class EmbiDatabase:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.raw_dir = self.root / "data" / "raw"
        self.processed_dir = self.root / "data" / "processed"
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        self.processed_dir.mkdir(parents=True, exist_ok=True)

    # ---------- ingest ----------
    def ingest_csv(self, csv_path: str | Path, archive: bool = True) -> str:
        """Parse one CSV, write its pickle snapshot, and (optionally) archive
        the raw file. Returns the snapshot date as YYYY-MM-DD string."""
        csv_path = Path(csv_path)
        df = parse_csv(csv_path)
        snap = str(df["SnapshotDate"].iloc[0])
        out = self.processed_dir / f"{snap}.pkl"
        df.to_pickle(out)
        if archive:
            target = self.raw_dir / csv_path.name
            try:
                if csv_path.resolve() != target.resolve():
                    if target.exists():
                        target.unlink()
                    shutil.copy(csv_path, target)
            except (OSError, PermissionError) as e:
                # Non-fatal: archive copy failed, snapshot still saved.
                print(f"  (warning: could not archive raw CSV: {e})")
        return snap

    def ingest_folder(self, folder: str | Path, pattern: str = "JPM_EMBI*.csv") -> list[str]:
        """Ingest every matching CSV in a folder. Idempotent."""
        folder = Path(folder)
        ingested = []
        for f in sorted(folder.glob(pattern)):
            ingested.append(self.ingest_csv(f))
        return ingested

    # ---------- query ----------
    def snapshot_dates(self) -> list[str]:
        return sorted(p.stem for p in self.processed_dir.glob("*.pkl"))

    def load_snapshot(self, date: str | None = None) -> pd.DataFrame:
        """Load one snapshot. If date is None, load the most recent."""
        dates = self.snapshot_dates()
        if not dates:
            raise FileNotFoundError("No snapshots ingested yet.")
        d = date or dates[-1]
        return pd.read_pickle(self.processed_dir / f"{d}.pkl")

    def load_master(self) -> pd.DataFrame:
        """Concatenate all snapshots into one long DataFrame."""
        dates = self.snapshot_dates()
        if not dates:
            raise FileNotFoundError("No snapshots ingested yet.")
        frames = [pd.read_pickle(self.processed_dir / f"{d}.pkl") for d in dates]
        return pd.concat(frames, ignore_index=True)

    def latest_date(self) -> str:
        return self.snapshot_dates()[-1]
