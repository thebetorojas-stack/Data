"""Parse JPM EMBI Global regional CSV files.

The file contains 6 sections separated by header rows in column C
(Instrument): Headline, By Region, By Country, By Credit Bucket,
By Sub Credit Bucket, By Sov/Quasi Sov/Corp.

This module produces a tidy long-format DataFrame with a `Section` column.
"""
from __future__ import annotations
import re
from pathlib import Path
from datetime import datetime
import pandas as pd


SECTION_MARKERS = {
    "By Region": "Region",
    "By Country": "Country",
    "By Credit Bucket": "Rating",
    "By Sub Credit Bucket": "SubRating",
    "By Sov/Quasi Sov/Corp": "SovQuasi",
}

# Region label assigned to each headline-level Bam Id
REGION_BAM_IDS = {
    "EMBIG_AFRICA": "Africa",
    "EMBIG_ASIA": "Asia",
    "EMBIG_EUROPE": "Europe",
    "EMBIG_LATIN": "Latin",
    "EMBIG_MIDEAST": "Middle East",
    "EMBIG_NONLAT": "Non Latin",
}

# Country -> Region mapping (we infer this from the file: country rows live
# between "By Region" and "By Credit Bucket" markers; we cross-check by region
# weight totals after parsing).  Manual mapping kept for resilience.
COUNTRY_REGION = {
    # Africa
    "Angola": "Africa", "Benin": "Africa", "Cameroon": "Africa",
    "Cote D'Ivoire": "Africa", "Egypt": "Africa", "Ethiopia": "Africa",
    "Gabon": "Africa", "Ghana": "Africa", "Kenya": "Africa",
    "Morocco": "Africa", "Mozambique": "Africa", "Namibia": "Africa",
    "Nigeria": "Africa", "Rwanda": "Africa", "Senegal": "Africa",
    "South Africa": "Africa", "Tunisia": "Africa", "Uganda": "Africa",
    "Zambia": "Africa", "Tanzania": "Africa",
    # Asia
    "China": "Asia", "India": "Asia", "Indonesia": "Asia", "Malaysia": "Asia",
    "Mongolia": "Asia", "Pakistan": "Asia", "Philippines": "Asia",
    "Sri Lanka": "Asia", "Vietnam": "Asia", "Papua New Guinea": "Asia",
    # Europe (CEEMEA non-MidEast non-Africa)
    "Albania": "Europe", "Armenia": "Europe", "Azerbaijan": "Europe",
    "Belarus": "Europe", "Bulgaria": "Europe", "Croatia": "Europe",
    "Georgia": "Europe", "Hungary": "Europe", "Kazakhstan": "Europe",
    "Kyrgyzstan": "Europe", "Latvia": "Europe", "Lithuania": "Europe",
    "Macedonia": "Europe", "Montenegro": "Europe", "Poland": "Europe",
    "Romania": "Europe", "Russia": "Europe", "Serbia": "Europe",
    "Slovakia": "Europe", "Slovenia": "Europe", "Tajikistan": "Europe",
    "Turkey": "Europe", "Ukraine": "Europe", "Uzbekistan": "Europe",
    "Bosnia": "Europe", "Montenegro": "Europe",
    # Latin
    "Argentina": "Latin", "Barbados": "Latin", "Belize": "Latin",
    "Bolivia": "Latin", "Brazil": "Latin", "Chile": "Latin",
    "Colombia": "Latin", "Costa Rica": "Latin", "Dominican Republic": "Latin",
    "Ecuador": "Latin", "El Salvador": "Latin", "Guatemala": "Latin",
    "Honduras": "Latin", "Jamaica": "Latin", "Mexico": "Latin",
    "Panama": "Latin", "Paraguay": "Latin", "Peru": "Latin",
    "Suriname": "Latin", "Trinidad & Tobago": "Latin", "Uruguay": "Latin",
    "Venezuela": "Latin", "Trinidad and Tobago": "Latin", "Bahamas": "Latin",
    "Guyana": "Latin", "Nicaragua": "Latin",
    "Republic of Congo": "Africa", "Congo": "Africa", "DR Congo": "Africa",
    # Middle East
    "Bahrain": "Middle East", "Iraq": "Middle East", "Israel": "Middle East",
    "Jordan": "Middle East", "Kuwait": "Middle East", "Lebanon": "Middle East",
    "Oman": "Middle East", "Qatar": "Middle East",
    "Saudi Arabia": "Middle East", "UAE": "Middle East", "Yemen": "Middle East",
}


# Filename pattern: JPM_EMBI_Global_regional_YYYY-MM-DD_xxx.csv
FILENAME_DATE_RE = re.compile(r"(\d{4}-\d{2}-\d{2})")


def _clean_columns(cols):
    """Strip whitespace and standardise column names."""
    out = []
    for c in cols:
        c = (c or "").strip()
        # collapse interior multiple spaces
        c = re.sub(r"\s+", " ", c)
        out.append(c)
    return out


def parse_date_from_filename(path: str | Path) -> str | None:
    m = FILENAME_DATE_RE.search(Path(path).name)
    return m.group(1) if m else None


def parse_csv(path: str | Path) -> pd.DataFrame:
    """Read one EMBI CSV and return a tidy long DataFrame.

    The returned frame has every original metric column plus:
      - Section: Headline / Region / Country / Rating / SubRating / SovQuasi
      - SourceFile: original filename
      - SnapshotDate: parsed datetime.date (from the Date column)
    """
    path = Path(path)
    raw = pd.read_csv(path, skipinitialspace=False)
    raw.columns = _clean_columns(raw.columns)

    # The first row (after header) is the EMBIG headline.  Subsequent rows
    # interleave section-marker rows (where Bam Id is empty and Instrument
    # holds e.g. "By Region") with data rows.
    bam_col = "Bam Id"
    inst_col = "Instrument"
    if bam_col not in raw.columns or inst_col not in raw.columns:
        raise ValueError(f"Unexpected columns: {raw.columns.tolist()[:5]}")

    section = "Headline"
    sections = []
    for _, row in raw.iterrows():
        bam = row[bam_col]
        inst = row[inst_col]
        bam_is_empty = pd.isna(bam) or str(bam).strip() == ""
        inst_str = "" if pd.isna(inst) else str(inst).strip()
        if bam_is_empty and inst_str in SECTION_MARKERS:
            section = SECTION_MARKERS[inst_str]
            sections.append(None)  # marker row -> drop
            continue
        if bam_is_empty:
            sections.append(None)
            continue
        sections.append(section)

    raw["Section"] = sections
    df = raw[raw["Section"].notna()].copy()

    # Parse date column to a single SnapshotDate (all rows in one file are the
    # same date).  Try a few formats.
    date_col = "Date"
    sample = df[date_col].dropna().iloc[0]
    snap = pd.to_datetime(sample, dayfirst=False, errors="coerce")
    if pd.isna(snap):
        snap = pd.to_datetime(sample, format="%d-%b-%Y", errors="coerce")
    if pd.isna(snap):
        # Fall back to filename
        fdate = parse_date_from_filename(path)
        snap = pd.to_datetime(fdate) if fdate else None
    df["SnapshotDate"] = snap.date() if snap is not None else None
    df["SourceFile"] = path.name

    # Force numeric on every metric column (everything except Bam Id / Date /
    # Instrument / ratings / Section / SourceFile / SnapshotDate).
    text_cols = {
        bam_col, "Date", inst_col, "Average S&P Rating",
        "Average Moody Rating", "Average Fitch Rating",
        "Section", "SourceFile", "SnapshotDate",
    }
    for c in df.columns:
        if c in text_cols:
            continue
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # Build a case-insensitive country->region lookup
    ci_country_region = {k.lower(): v for k, v in COUNTRY_REGION.items()}

    def region_of(row):
        if row["Section"] == "Region":
            return REGION_BAM_IDS.get(row[bam_col], row[inst_col])
        if row["Section"] == "Country":
            name = str(row[inst_col]).strip().lower()
            return ci_country_region.get(name, "Unknown")
        return None

    df["Region"] = df.apply(region_of, axis=1)
    # Title-case country instrument names so "MONTENEGRO" -> "Montenegro"
    df.loc[df["Section"] == "Country", inst_col] = (
        df.loc[df["Section"] == "Country", inst_col]
        .astype(str).str.title()
        .replace({"Uae": "UAE", "Dr Congo": "DR Congo"})
    )

    # Add a coarse rating bucket from S&P (IG vs HY) for every row
    df["IG_Flag"] = df["Average S&P Rating"].map(_is_ig)

    return df.reset_index(drop=True)


_IG_RATINGS = {
    "AAA", "AA+", "AA", "AA-", "A+", "A", "A-",
    "BBB+", "BBB", "BBB-",
}


def _is_ig(r):
    if pd.isna(r):
        return None
    r = str(r).strip()
    if not r:
        return None
    return r in _IG_RATINGS


def rating_bucket(rating: str) -> str:
    """Map a granular S&P rating to a coarse bucket: AA, A, BBB, BB, B, CCC, NR."""
    if pd.isna(rating) or not str(rating).strip():
        return "NR"
    r = str(rating).strip().upper()
    if r.startswith("AAA") or r.startswith("AA"):
        return "AA"
    if r.startswith("A"):
        return "A"
    if r.startswith("BBB"):
        return "BBB"
    if r.startswith("BB"):
        return "BB"
    if r.startswith("CCC") or r.startswith("CC") or r.startswith("C") or r.startswith("D"):
        return "CCC"
    if r.startswith("B"):
        return "B"
    return "NR"
