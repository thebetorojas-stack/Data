#!/usr/bin/env python3
"""EMBI Monitor — update CLI.

Usage:
    # Default: scan ./data/raw and ./inbox for new CSVs, rebuild Excel
    python update.py

    # Ingest one or more specific files
    python update.py path/to/JPM_EMBI_Global_regional_2026-04-27_*.csv

    # Just rebuild the Excel from existing snapshots
    python update.py --rebuild-only

    # Show what's in the database
    python update.py --status
"""
from __future__ import annotations
import sys
from pathlib import Path
import argparse

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from embi_monitor.database import EmbiDatabase
from embi_monitor.report import build_workbook


def main():
    ap = argparse.ArgumentParser(description="EMBI Monitor updater.")
    ap.add_argument("paths", nargs="*",
                    help="Specific CSV file(s) to ingest. If omitted, scans default folders.")
    ap.add_argument("--rebuild-only", action="store_true",
                    help="Skip ingestion; just rebuild the workbook.")
    ap.add_argument("--status", action="store_true",
                    help="Show DB status and exit.")
    ap.add_argument("--out", default=str(ROOT / "EMBI_Monitor.xlsx"),
                    help="Output Excel path (default: ./EMBI_Monitor.xlsx)")
    ap.add_argument("--inbox", default=str(ROOT / "inbox"),
                    help="Inbox folder to scan for new CSVs (default: ./inbox)")
    args = ap.parse_args()

    db = EmbiDatabase(ROOT)

    if args.status:
        dates = db.snapshot_dates()
        print(f"DB root: {db.root}")
        print(f"Snapshots: {len(dates)}")
        for d in dates:
            print(f"  - {d}")
        return

    new_dates = []
    if not args.rebuild_only:
        # 1) explicit paths first
        for p in args.paths:
            d = db.ingest_csv(p)
            print(f"  ingested {Path(p).name} -> {d}")
            new_dates.append(d)
        # 2) scan inbox
        inbox = Path(args.inbox)
        if inbox.exists():
            for f in sorted(inbox.glob("JPM_EMBI*.csv")):
                d = db.ingest_csv(f)
                print(f"  ingested (inbox) {f.name} -> {d}")
                new_dates.append(d)
        # 3) re-scan raw archive (in case files were added manually)
        for f in sorted((ROOT / "data" / "raw").glob("JPM_EMBI*.csv")):
            d = db.ingest_csv(f)
            # idempotent: re-ingestion just rewrites same pickle

    dates = db.snapshot_dates()
    if not dates:
        print("No snapshots in DB. Drop a JPM_EMBI*.csv into ./inbox/ or pass it as an argument.")
        sys.exit(1)

    out = build_workbook(db, args.out)
    print(f"\nWorkbook: {out}")
    print(f"Latest snapshot: {db.latest_date()}")
    print(f"Snapshots in DB: {len(dates)} -> {dates[0]} … {dates[-1]}")


if __name__ == "__main__":
    main()
